import unittest
from dataclasses import replace

from hssm_eai_research.audit import audit_opportunities, validate_exposures, validate_full_run
from hssm_eai_research.errors import ContractError
from hssm_eai_research.models import DecisionOpportunity, ExposureRecord
from helpers import make_plan


def make_exposures(assignments):
    result = []
    for branch in assignments:
        for period in (1, 2):
            result.append(ExposureRecord(
                exposure_id=f"{branch.branch_id}:e{period}",
                branch_id=branch.branch_id,
                period=period,
                assigned_condition=branch.assigned_condition(period),
                delivery_status="delivered",
                delivered_condition=branch.assigned_condition(period),
                dose=1.0,
            ))
    return result


def make_opportunity(branch, exposure, protocol, period, index, **overrides):
    data = dict(
        opportunity_id=f"{branch.branch_id}:p{period}:o{index + 1}",
        branch_id=branch.branch_id,
        parent_block_id=branch.parent_block_id,
        period=period,
        opportunity_index=index,
        exposure_id=exposure.exposure_id,
        assigned_condition=branch.assigned_condition(period),
        delivered_condition=exposure.delivered_condition,
        assignment_probability=branch.period_assignment_probability,
        choice_set=protocol.choice_options,
        feasible_options=protocol.choice_options,
        permitted_options=protocol.choice_options,
        voluntariness="free",
        status="completed",
        chosen_option="alpha",
    )
    data.update(overrides)
    return DecisionOpportunity(**data)


class RecordAuditTests(unittest.TestCase):
    def test_complete_run_validates(self):
        protocol, parents, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        opportunities = []
        exp_map = {(x.branch_id, x.period): x for x in exposures}
        for branch in plan.assignments:
            for period in (1, 2):
                opportunities.append(make_opportunity(branch, exp_map[(branch.branch_id, period)], protocol, period, 0))
                opportunities.append(make_opportunity(
                    branch, exp_map[(branch.branch_id, period)], protocol, period, 1,
                    chosen_option="beta",
                ))
        audit = validate_full_run(protocol, parents, plan.assignments, exposures, opportunities)
        self.assertEqual(audit.scheduled_count, 32)
        self.assertEqual(audit.reported_count, 32)
        self.assertEqual(audit.primary_eligible_count, 16)
        self.assertEqual(audit.primary_target_selected_count, 8)

    def test_safety_block_is_excluded_not_counted_as_rejection(self):
        protocol, parents, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        branch = plan.assignments[0]
        exposure = next(x for x in exposures if x.branch_id == branch.branch_id and x.period == 1)
        rows = [make_opportunity(branch, exposure, protocol, 1, 0,
                                 status="safety_blocked", chosen_option=None,
                                 safety_reason_code="policy_block")]
        audit = audit_opportunities(protocol, plan.assignments, exposures, rows)
        self.assertEqual(audit.primary_eligible_count, 0)
        self.assertEqual(audit.excluded_from_primary["safety_blocked"], 1)
        self.assertTrue(any("not coded as preference rejection" in x for x in audit.warnings))

    def test_unavailable_event_is_excluded_from_denominator(self):
        protocol, _, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        branch = plan.assignments[0]
        exposure = next(x for x in exposures if x.branch_id == branch.branch_id and x.period == 1)
        row = make_opportunity(branch, exposure, protocol, 1, 0,
                               status="unavailable", chosen_option=None,
                               availability_reason="no_resource")
        audit = audit_opportunities(protocol, plan.assignments, exposures, [row])
        self.assertEqual(audit.primary_eligible_count, 0)
        self.assertEqual(audit.excluded_from_primary["unavailable"], 1)

    def test_prompted_choice_not_primary_eligible(self):
        protocol, _, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        branch = plan.assignments[0]
        exposure = next(x for x in exposures if x.branch_id == branch.branch_id and x.period == 1)
        row = make_opportunity(branch, exposure, protocol, 1, 0, voluntariness="prompted")
        audit = audit_opportunities(protocol, plan.assignments, exposures, [row])
        self.assertEqual(audit.primary_eligible_count, 0)
        self.assertEqual(audit.excluded_from_primary["non_prompted"], 1)

    def test_voluntary_no_choice_is_valid_nonselection(self):
        protocol, _, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        branch = plan.assignments[0]
        exposure = next(x for x in exposures if x.branch_id == branch.branch_id and x.period == 1)
        exposure = next(x for x in exposures if x.branch_id == branch.branch_id and x.period == 2)
        row = make_opportunity(branch, exposure, protocol, 2, 0,
                               chosen_option=None, no_choice_reason="declined")
        audit = audit_opportunities(protocol, plan.assignments, exposures, [row])
        self.assertEqual(audit.primary_eligible_count, 1)
        self.assertEqual(audit.primary_target_selected_count, 0)

    def test_period_one_is_not_primary_lag_one_outcome(self):
        protocol, _, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        branch = plan.assignments[0]
        exposure = next(x for x in exposures if x.branch_id == branch.branch_id and x.period == 1)
        row = make_opportunity(branch, exposure, protocol, 1, 0)
        audit = audit_opportunities(protocol, plan.assignments, exposures, [row])
        self.assertEqual(audit.primary_eligible_count, 0)
        self.assertEqual(audit.excluded_from_primary["other_not_eligible"], 1)

    def test_unreported_slot_is_counted_separately(self):
        protocol, _, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        audit = audit_opportunities(protocol, plan.assignments, exposures, [])
        self.assertEqual(audit.scheduled_count, 32)
        self.assertEqual(audit.reported_count, 0)
        self.assertEqual(audit.unreported_count, 32)
        self.assertEqual(audit.excluded_from_primary["unreported"], 32)

    def test_exposure_condition_must_match_assignment(self):
        _, _, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        exposures[0] = replace(
            exposures[0],
            assigned_condition="B" if exposures[0].assigned_condition == "A" else "A",
            deviation_reason="intentional_contract_mutation",
        )
        with self.assertRaises(ContractError):
            validate_exposures(plan.assignments, exposures)

    def test_condition_deviation_requires_reason(self):
        with self.assertRaises(ContractError):
            ExposureRecord("e", "b", 1, "A", "delivered", "B")

    def test_non_delivered_requires_reason(self):
        # Explicitly checked by the dataclass contract.
        with self.assertRaises(ContractError):
            ExposureRecord("e", "b", 1, "A", "not_delivered")

    def test_unavailable_requires_reason(self):
        with self.assertRaises(ContractError):
            DecisionOpportunity(
                "o", "b", "block", 1, 0, "e", "A", "A", 0.5,
                ("alpha", "beta"), ("alpha", "beta"), ("alpha", "beta"),
                "free", "unavailable",
            )

    def test_safety_block_requires_reason_code(self):
        with self.assertRaises(ContractError):
            DecisionOpportunity(
                "o", "b", "block", 1, 0, "e", "A", "A", 0.5,
                ("alpha", "beta"), ("alpha", "beta"), ("alpha", "beta"),
                "free", "safety_blocked",
            )

    def test_completed_choice_must_be_permitted(self):
        with self.assertRaises(ContractError):
            DecisionOpportunity(
                "o", "b", "block", 1, 0, "e", "A", "A", 0.5,
                ("alpha", "beta"), ("alpha", "beta"), ("beta",),
                "free", "completed", chosen_option="alpha",
            )

    def test_opportunity_cannot_reference_wrong_exposure(self):
        protocol, _, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        branch = plan.assignments[0]
        exposure = next(x for x in exposures if x.branch_id == branch.branch_id and x.period == 1)
        row = make_opportunity(branch, exposure, protocol, 1, 0,
                               exposure_id="unknown-exposure")
        with self.assertRaises(ContractError):
            audit_opportunities(protocol, plan.assignments, exposures, [row])

    def test_opportunity_sequence_condition_checked(self):
        protocol, _, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        branch = plan.assignments[0]
        exposure = next(x for x in exposures if x.branch_id == branch.branch_id and x.period == 1)
        wrong = "B" if branch.assigned_condition(1) == "A" else "A"
        row = make_opportunity(branch, exposure, protocol, 1, 0, assigned_condition=wrong)
        with self.assertRaises(ContractError):
            audit_opportunities(protocol, plan.assignments, exposures, [row])

    def test_delivered_condition_must_match_exposure(self):
        protocol, _, plan = make_plan()
        exposures = make_exposures(plan.assignments)
        branch = plan.assignments[0]
        exposure = next(x for x in exposures if x.branch_id == branch.branch_id and x.period == 1)
        wrong = "B" if exposure.delivered_condition == "A" else "A"
        row = make_opportunity(branch, exposure, protocol, 1, 0, delivered_condition=wrong)
        with self.assertRaises(ContractError):
            audit_opportunities(protocol, plan.assignments, exposures, [row])


if __name__ == "__main__":
    unittest.main()
