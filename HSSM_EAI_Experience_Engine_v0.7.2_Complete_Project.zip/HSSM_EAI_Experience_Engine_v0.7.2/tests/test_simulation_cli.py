import json
import tempfile
import unittest
from pathlib import Path

from hssm_eai_research.cli import create_calibration_run, create_synthetic_run


class SimulationCliTests(unittest.TestCase):
    def test_synthetic_run_writes_dataset_and_diagnostic(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "synthetic"
            result = create_synthetic_run(out, "ar_only", 55, 8, 4)
            self.assertEqual(result["manifest"]["scenario"], "ar_only")
            self.assertTrue((out / "scenario_manifest.json").is_file())
            self.assertTrue((out / "branch_assignments.jsonl").is_file())
            self.assertTrue((out / "observations.jsonl").is_file())
            self.assertTrue((out / "diagnostic_report.json").is_file())
            report = json.loads((out / "diagnostic_report.json").read_text(encoding="utf-8"))
            self.assertFalse(report["confirmatory_inference_enabled"])

    def test_calibration_run_writes_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "calibration"
            result = create_calibration_run(out, 20, 16, 6, 100, 0.05)
            self.assertEqual(len(result["scenario_results"]), 10)
            self.assertTrue((out / "calibration_report.json").is_file())


if __name__ == "__main__":
    unittest.main()
