import json
import unittest
from pathlib import Path

try:
    import jsonschema
except ImportError:
    jsonschema = None

from hssm_eai_research.simulation import SimulationConfig, diagnose_lag1, generate_synthetic_dataset, run_calibration_suite

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipIf(jsonschema is None, "Install the test extra: pip install -e '.[test]'")
class SimulationSchemaTests(unittest.TestCase):
    def test_synthetic_manifest_schema(self):
        dataset = generate_synthetic_dataset(SimulationConfig("null", parent_blocks=8, steps_per_period=4))
        schema = json.loads((ROOT / "schemas" / "synthetic_dataset_manifest.schema.json").read_text())
        jsonschema.validate(dataset["manifest"], schema)

    def test_contamination_manifest_schema(self):
        dataset = generate_synthetic_dataset(SimulationConfig("branch_contamination", parent_blocks=8, steps_per_period=4))
        schema = json.loads((ROOT / "schemas" / "synthetic_dataset_manifest.schema.json").read_text())
        jsonschema.validate(dataset["manifest"], schema)

    def test_diagnostic_schema(self):
        dataset = generate_synthetic_dataset(SimulationConfig("null", parent_blocks=8, steps_per_period=4))
        report = diagnose_lag1(dataset)
        schema = json.loads((ROOT / "schemas" / "diagnostic_report.schema.json").read_text())
        jsonschema.validate(report, schema)

    def test_calibration_schema(self):
        report = run_calibration_suite(replicates=20, parent_blocks=16, steps_per_period=6)
        schema = json.loads((ROOT / "schemas" / "calibration_report.schema.json").read_text())
        jsonschema.validate(report, schema)


if __name__ == "__main__":
    unittest.main()
