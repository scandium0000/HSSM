import unittest
from dataclasses import replace

from hssm_eai_research.constants import SEQUENCE_CELLS
from hssm_eai_research.errors import AllocationError, ContractError
from hssm_eai_research.protocol import ResearchProtocol, create_sequence_plan, validate_sequence_plan
from helpers import make_parents, make_protocol


class ProtocolTests(unittest.TestCase):
    def test_balanced_four_cells_per_parent(self):
        parents = make_parents(3)
        protocol = make_protocol(parents)
        plan = create_sequence_plan(protocol, parents)
        for parent in parents:
            rows = [r for r in plan.assignments if r.parent_checkpoint_id == parent.checkpoint_id]
            self.assertEqual(sorted(r.sequence for r in rows), sorted(SEQUENCE_CELLS))
            self.assertEqual(len({r.parent_block_id for r in rows}), 1)
            self.assertEqual(len({r.parent_snapshot_sha256 for r in rows}), 1)

    def test_allocation_is_reproducible(self):
        parents = make_parents(2)
        protocol = make_protocol(parents, seed=123)
        a = create_sequence_plan(protocol, parents)
        b = create_sequence_plan(protocol, parents)
        self.assertEqual([x.to_dict() for x in a.assignments], [x.to_dict() for x in b.assignments])
        self.assertEqual(a.plan_sha256, b.plan_sha256)

    def test_different_seed_changes_at_least_one_order(self):
        parents = make_parents(5)
        a = create_sequence_plan(make_protocol(parents, seed=101), parents)
        b = create_sequence_plan(make_protocol(parents, seed=202), parents)
        self.assertNotEqual([x.sequence for x in a.assignments], [x.sequence for x in b.assignments])

    def test_assignment_probabilities_are_explicit(self):
        _, _, plan = __import__("helpers").make_plan()
        self.assertTrue(all(x.sequence_assignment_probability == 0.25 for x in plan.assignments))
        self.assertTrue(all(x.period_assignment_probability == 0.5 for x in plan.assignments))

    def test_missing_parent_rejected(self):
        parents = make_parents(2)
        protocol = make_protocol(parents)
        with self.assertRaises(AllocationError):
            create_sequence_plan(protocol, parents[:1])

    def test_snapshot_missing_required_component_rejected(self):
        parents = make_parents(1)
        parent = parents[0]
        incomplete = type(parent)(parent.checkpoint_id, {k: v for k, v in parent.snapshot_components.items() if k != "rng_state"})
        protocol = make_protocol([parent])
        with self.assertRaises(AllocationError):
            create_sequence_plan(protocol, [incomplete])

    def test_duplicate_mutable_namespace_detected(self):
        protocol, parents, plan = __import__("helpers").make_plan()
        rows = list(plan.assignments)
        rows[1] = replace(rows[1], mutable_state_namespace_id=rows[0].mutable_state_namespace_id)
        with self.assertRaises(AllocationError):
            validate_sequence_plan(protocol, parents, rows)

    def test_duplicate_mutable_store_detected(self):
        protocol, parents, plan = __import__("helpers").make_plan()
        rows = list(plan.assignments)
        stores = dict(rows[1].mutable_store_ids)
        stores["episodic_store"] = rows[0].mutable_store_ids["episodic_store"]
        rows[1] = replace(rows[1], mutable_store_ids=stores)
        with self.assertRaises(AllocationError):
            validate_sequence_plan(protocol, parents, rows)

    def test_wrong_sequence_probability_detected(self):
        protocol, parents, plan = __import__("helpers").make_plan()
        rows = list(plan.assignments)
        rows[0] = replace(rows[0], sequence_assignment_probability=0.5)
        with self.assertRaises(AllocationError):
            validate_sequence_plan(protocol, parents, rows)

    def test_mutated_parent_snapshot_detected(self):
        protocol, parents, plan = __import__("helpers").make_plan()
        rows = list(plan.assignments)
        rows[0] = replace(rows[0], parent_snapshot_sha256="0" * 64)
        with self.assertRaises(AllocationError):
            validate_sequence_plan(protocol, parents, rows)

    def test_protocol_rejects_target_not_in_choice_set(self):
        parents = make_parents(1)
        with self.assertRaises(ContractError):
            ResearchProtocol("p", "gamma", ("alpha", "beta"), (parents[0].checkpoint_id,), 1, 42)

    def test_protocol_rejects_bad_weights(self):
        parents = make_parents(1)
        with self.assertRaises(ContractError):
            ResearchProtocol(
                "p", "alpha", ("alpha", "beta"), (parents[0].checkpoint_id,), 1, 42,
                current_context_weights={"A": 0.2, "B": 0.2},
            )


if __name__ == "__main__":
    unittest.main()
