from hssm_eai_research.constants import REQUIRED_SNAPSHOT_COMPONENTS
from hssm_eai_research.models import ParentCheckpoint
from hssm_eai_research.protocol import ResearchProtocol, create_sequence_plan
from hssm_eai_research.serialization import sha256_text


def make_parents(count=2, seed=42):
    result = []
    for i in range(count):
        checkpoint_id = f"parent-{i + 1}"
        components = {
            name: sha256_text(f"{checkpoint_id}:{name}:{seed}")
            for name in REQUIRED_SNAPSHOT_COMPONENTS
        }
        result.append(ParentCheckpoint(checkpoint_id, components, metadata={"fixture": True}))
    return result


def make_protocol(parents=None, seed=42, opportunities=2):
    parents = parents or make_parents()
    return ResearchProtocol(
        protocol_id="test-protocol",
        target_activity="alpha",
        choice_options=("alpha", "beta"),
        parent_checkpoint_ids=tuple(p.checkpoint_id for p in parents),
        opportunities_per_branch_period=opportunities,
        seed=seed,
    )


def make_plan(protocol=None, parents=None):
    parents = parents or make_parents()
    protocol = protocol or make_protocol(parents)
    return protocol, parents, create_sequence_plan(protocol, parents)
