"""JSON Schema validation for the shipped synthetic run artifacts."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

from hssm_eai_research.cli import create_demo


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_DIR = PROJECT_ROOT / "schemas"


class SchemaContractTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tempdir = tempfile.TemporaryDirectory()
        self.run_dir = Path(self.tempdir.name) / "run"
        create_demo(self.run_dir, seed=17, blocks=2)

    def tearDown(self) -> None:
        self.tempdir.cleanup()

    def _validate_one(self, schema_name: str, data: object) -> None:
        schema = json.loads((SCHEMA_DIR / schema_name).read_text(encoding="utf-8"))
        validator = Draft202012Validator(schema)
        errors = list(validator.iter_errors(data))
        self.assertEqual(errors, [], f"{schema_name}: {errors[:3]}")

    def test_protocol_schema(self) -> None:
        data = json.loads((self.run_dir / "protocol.json").read_text(encoding="utf-8"))
        self._validate_one("research_protocol.schema.json", data)

    def test_parent_checkpoint_schema(self) -> None:
        data = json.loads((self.run_dir / "parent_checkpoints.json").read_text(encoding="utf-8"))
        schema = json.loads((SCHEMA_DIR / "parent_checkpoint.schema.json").read_text(encoding="utf-8"))
        validator = Draft202012Validator(schema)
        errors = [(i, list(validator.iter_errors(row))) for i, row in enumerate(data)]
        errors = [(i, err) for i, group in errors for err in group]
        self.assertEqual(errors, [])

    def test_branch_assignment_schema(self) -> None:
        self._validate_jsonl("branch_assignment.schema.json", "branch_assignments.jsonl")

    def test_exposure_schema(self) -> None:
        self._validate_jsonl("exposure_record.schema.json", "exposures.jsonl")

    def test_decision_opportunity_schema(self) -> None:
        self._validate_jsonl("decision_opportunity.schema.json", "opportunities.jsonl")

    def _validate_jsonl(self, schema_name: str, filename: str) -> None:
        schema = json.loads((SCHEMA_DIR / schema_name).read_text(encoding="utf-8"))
        validator = Draft202012Validator(schema)
        rows = [json.loads(line) for line in (self.run_dir / filename).read_text(encoding="utf-8").splitlines() if line]
        errors = [(i, err.message) for i, row in enumerate(rows) for err in validator.iter_errors(row)]
        self.assertEqual(errors, [], f"{schema_name}: {errors[:3]}")


if __name__ == "__main__":
    unittest.main()
