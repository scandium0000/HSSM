"""Command-line dataset round-trip and integrity checks."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from hssm_eai_research.cli import create_demo, validate_directory
from hssm_eai_research.errors import ContractError


class CliRoundTripTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tempdir = tempfile.TemporaryDirectory()
        self.run_dir = Path(self.tempdir.name) / "run"
        create_demo(self.run_dir, seed=91, blocks=2)

    def tearDown(self) -> None:
        self.tempdir.cleanup()

    def test_demo_round_trip_validates(self) -> None:
        result = validate_directory(self.run_dir)
        self.assertEqual(result["scheduled_count"], 32)
        self.assertEqual(result["reported_count"] + result["unreported_count"], 32)

    def test_tampered_protocol_hash_rejected(self) -> None:
        path = self.run_dir / "protocol.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["protocol_sha256"] = "0" * 64
        path.write_text(json.dumps(payload), encoding="utf-8")
        with self.assertRaisesRegex(ContractError, "protocol_sha256"):
            validate_directory(self.run_dir)

    def test_tampered_plan_hash_rejected(self) -> None:
        path = self.run_dir / "sequence_plan.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["plan_sha256"] = "0" * 64
        path.write_text(json.dumps(payload), encoding="utf-8")
        with self.assertRaisesRegex(ContractError, "plan_sha256"):
            validate_directory(self.run_dir)


if __name__ == "__main__":
    unittest.main()
