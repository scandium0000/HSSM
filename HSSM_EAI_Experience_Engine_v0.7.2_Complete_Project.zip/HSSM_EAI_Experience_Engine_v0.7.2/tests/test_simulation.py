import json
import unittest

from hssm_eai_research.errors import ContractError
from hssm_eai_research.simulation import (
    SimulationConfig,
    audit_synthetic_branch_isolation,
    calibrate_scenario,
    diagnose_lag1,
    generate_synthetic_dataset,
    run_calibration_suite,
    wilson_interval,
)


class SyntheticGeneratorTests(unittest.TestCase):
    def test_generation_is_deterministic_for_fixed_seed(self):
        config = SimulationConfig("persistent_carryover", parent_blocks=8, steps_per_period=4, seed=99)
        self.assertEqual(generate_synthetic_dataset(config), generate_synthetic_dataset(config))

    def test_each_parent_has_all_four_sequence_cells(self):
        dataset = generate_synthetic_dataset(SimulationConfig("null", parent_blocks=9, steps_per_period=4))
        for block in {row["parent_block_id"] for row in dataset["assignments"]}:
            rows = [row for row in dataset["assignments"] if row["parent_block_id"] == block]
            self.assertEqual({row["sequence"] for row in rows}, {"AA", "AB", "BA", "BB"})
            self.assertEqual(len({row["mutable_state_namespace_id"] for row in rows}), 4)

    def test_negative_control_generators_have_no_carryover_parameter(self):
        for scenario in ("null", "ar_only", "trend_only", "learning_only"):
            dataset = generate_synthetic_dataset(SimulationConfig(scenario, parent_blocks=8, steps_per_period=4))
            self.assertEqual(dataset["manifest"]["synthetic_parameters"]["carryover_effect"], 0.0)

    def test_ar_only_has_autocorrelation_without_carryover(self):
        dataset = generate_synthetic_dataset(SimulationConfig("ar_only", parent_blocks=8, steps_per_period=4))
        params = dataset["manifest"]["synthetic_parameters"]
        self.assertGreater(params["ar_rho"], 0.0)
        self.assertEqual(params["carryover_effect"], 0.0)

    def test_persistent_carryover_is_detected_in_large_synthetic_fixture(self):
        dataset = generate_synthetic_dataset(
            SimulationConfig("persistent_carryover", parent_blocks=48, steps_per_period=16, seed=12)
        )
        result = diagnose_lag1(dataset)
        self.assertEqual(result["status"], "diagnostic_only")
        self.assertGreater(result["estimate"], 0.15)
        self.assertTrue(result["screen_reject_at_alpha"])
        self.assertFalse(result["confirmatory_inference_enabled"])

    def test_autocorrelation_only_does_not_automatically_become_large_carryover(self):
        dataset = generate_synthetic_dataset(
            SimulationConfig("ar_only", parent_blocks=48, steps_per_period=16, seed=12)
        )
        result = diagnose_lag1(dataset)
        self.assertEqual(result["status"], "diagnostic_only")
        self.assertLess(abs(result["estimate"]), 0.15)
        self.assertFalse(result["confirmatory_inference_enabled"])

    def test_missing_and_safety_blocked_rows_have_no_target_outcome(self):
        dataset = generate_synthetic_dataset(
            SimulationConfig("missing_safety", parent_blocks=16, steps_per_period=10, seed=19)
        )
        excluded = [row for row in dataset["rows"] if row["status"] != "completed"]
        self.assertTrue(excluded)
        self.assertTrue(all(row["target_selected"] is None for row in excluded))
        self.assertTrue(any(row["status"] == "safety_blocked" for row in excluded))

    def test_isolation_audit_detects_deliberate_namespace_collision(self):
        dataset = generate_synthetic_dataset(
            SimulationConfig("branch_contamination", parent_blocks=8, steps_per_period=4, seed=4)
        )
        audit = audit_synthetic_branch_isolation(dataset["assignments"])
        self.assertFalse(audit["valid"])
        self.assertTrue(audit["namespace_collisions"])
        diagnostic = diagnose_lag1(dataset)
        self.assertEqual(diagnostic["status"], "invalid_branch_isolation")

    def test_isolation_audit_detects_namespace_reuse_across_parent_blocks(self):
        dataset = generate_synthetic_dataset(SimulationConfig("null", parent_blocks=8, steps_per_period=4))
        rows = dataset["assignments"]
        rows[4]["mutable_state_namespace_id"] = rows[0]["mutable_state_namespace_id"]
        audit = audit_synthetic_branch_isolation(rows)
        self.assertFalse(audit["valid"])
        self.assertTrue(audit["namespace_collisions"])

    def test_isolation_audit_accepts_clean_synthetic_branches(self):
        dataset = generate_synthetic_dataset(SimulationConfig("null", parent_blocks=8, steps_per_period=4))
        self.assertTrue(audit_synthetic_branch_isolation(dataset["assignments"])["valid"])

    def test_degenerate_variance_returns_json_safe_review(self):
        dataset = generate_synthetic_dataset(SimulationConfig("null", parent_blocks=8, steps_per_period=4, seed=1))
        for row in dataset["rows"]:
            if row["period"] == 2 and row["status"] == "completed":
                row["target_selected"] = False
        result = diagnose_lag1(dataset)
        self.assertEqual(result["status"], "degenerate_variance_review")
        json.dumps(result, allow_nan=False)

    def test_calibration_is_reproducible(self):
        a = calibrate_scenario("ar_only", replicates=20, parent_blocks=16, steps_per_period=6, seed=321)
        b = calibrate_scenario("ar_only", replicates=20, parent_blocks=16, steps_per_period=6, seed=321)
        self.assertEqual(a, b)

    def test_wilson_interval_contains_observed_rate(self):
        lower, upper = wilson_interval(5, 100)
        self.assertLessEqual(lower, 0.05)
        self.assertGreaterEqual(upper, 0.05)

    def test_invalid_simulation_configuration_rejected(self):
        with self.assertRaises(ContractError):
            SimulationConfig("unknown")
        with self.assertRaises(ContractError):
            SimulationConfig("null", parent_blocks=2)

    def test_calibration_suite_keeps_confirmatory_inference_disabled(self):
        report = run_calibration_suite(replicates=20, parent_blocks=16, steps_per_period=6, seed=12)
        self.assertFalse(report["confirmatory_inference_enabled"])
        self.assertEqual(len(report["scenario_results"]), 10)
        self.assertIn("ar_only", [row["scenario"] for row in report["scenario_results"]])


if __name__ == "__main__":
    unittest.main()
