# HSSM-EAI Experience Engine — v0.7.2

**Release:** `0.7.2` — Synthetic Longitudinal Data Generators & Diagnostic Calibration  
**Status:** standalone research-layer increment; CPU-first; synthetic fixtures only  
**Runtime:** Python 3.10+; standard library only (JSON Schema validation is in the optional test extra)

## Purpose

This release extends the v0.7.1 lineage and four-sequence contract with a synthetic longitudinal data laboratory. The goal is to test whether a simple block-aware lag-1 diagnostic confuses prior-exposure carryover with residual autocorrelation, time trends, or cumulative-learning-shaped trends.

The simulator deliberately separates known synthetic mechanisms. It does not control or update any Agent. Every dataset is generated using an explicit deterministic seed and records the generating assumptions in a manifest.

## Added capabilities

- Deterministic two-period synthetic traces across `AA`, `AB`, `BA`, and `BB` sequence cells.
- Scenario presets for null, AR-only, trend-only, learning-only, transient carryover, weak carryover, persistent carryover, combined mechanisms, heterogeneous carryover, missingness/safety blocking, and deliberate branch contamination.
- Parent-blocked lag-1 contrast: compare prior A versus prior B within each current-period context and parent block, then average the current-context contrasts.
- Parent-block standard error and asymptotic normal screening statistic.
- Wilson intervals and Monte Carlo rejection-rate summaries across repeated synthetic datasets.
- Independent branch-manifest integrity audit for complete sequence cells, unique branch IDs, and globally unique mutable-state namespaces.
- JSON schemas, CLI commands, tests, and stored synthetic example runs.

## Non-claims

This release does **not**:

- implement a confirmatory causal estimator for real or evolving Agents;
- solve time-varying confounding, interference, informative availability/missingness, non-stationarity, or all forms of serial dependence;
- establish general statistical power from the selected synthetic effect sizes;
- infer emotions, genuine interests, subjective experience, or consciousness;
- enable autonomous behavior, expand permissions, or modify Agent memory or model weights;
- prove a runtime truly isolates branches merely because its namespace manifest is unique;
- claim compatibility or source integration with the unrecovered historical Experience Engine v0.6 tree.

`confirmatory_inference_enabled` remains `false` in all diagnostic and calibration outputs.

## Install

```bash
python -m pip install -e ".[test]"
```

## Quick start

Generate one synthetic scenario:

```bash
python -m hssm_eai_research simulate \
  --scenario persistent_carryover --seed 42 --blocks 32 --steps 10 \
  --output runs/synthetic_persistent
```

Run the calibration through the Python API example (after installing the package):

```bash
python examples/run_synthetic_calibration.py --replicates 200 --seed 42000
```

Run the multi-scenario Monte Carlo calibration suite:

```bash
python -m hssm_eai_research calibrate \
  --replicates 200 --blocks 32 --steps 10 --seed 42000 \
  --output runs/calibration
```

The earlier v0.7.1 lineage-contract commands remain available:

```bash
python -m hssm_eai_research demo --seed 42 --blocks 8 --output runs/demo
python -m hssm_eai_research validate --input runs/demo
```

## Synthetic scenario catalog

| Scenario | Main injected mechanism | Carryover truth |
|---|---|---:|
| `null` | Random intercepts + current-context effect | 0 |
| `ar_only` | AR(1) residual dependence | 0 |
| `trend_only` | Period/time trend | 0 |
| `learning_only` | Smooth cumulative-learning trend | 0 |
| `transient_carryover` | Prior-condition effect with decay | Non-zero |
| `weak_carryover` | Small persistent prior-condition effect | Non-zero, weak |
| `persistent_carryover` | Persistent prior-condition effect | Non-zero |
| `combined` | Carryover + trend + learning + AR(1) | Non-zero |
| `heterogeneous_carryover` | Prior effect varies across parent blocks | Non-zero |
| `missing_safety` | Carryover plus missing / unavailable / blocked / failed rows | Non-zero |
| `branch_contamination` | Shared mutable namespace across branches | Invalid by construction |

## Diagnostic and interpretation

`diagnose_lag1()` compares mean period-2 binary outcomes following prior A versus prior B, separately within current context A and B, and averages the two contrasts equally within each parent block. It then summarizes the parent-block contrasts. This preserves the parent block as the top-level replication unit and avoids treating repeated time points as independent parent-level samples.

The diagnostic emits an asymptotic normal p-value and interval only as a screening summary. It is not a confirmatory causal estimator. The negative controls are useful for testing whether the method is fooled by the particular AR(1), time-trend, and learning-trend generators included here; they do not cover all possible mechanisms.

All output states that confirmatory inference is disabled. A blocked or unavailable opportunity never becomes a false binary rejection. An invalid branch namespace manifest blocks the diagnostic.

## Output files

A `simulate` run contains:

| File | Purpose |
|---|---|
| `scenario_manifest.json` | Scenario, seed, and synthetic generator parameters |
| `branch_assignments.jsonl` | Four sequence cells and isolated namespace identifiers per parent |
| `observations.jsonl` | Repeated binary outcomes or explicit non-completed statuses |
| `diagnostic_report.json` | Block-aware contrast and interpretation limits |

A `calibrate` run contains `calibration_report.json`, including scenario-wise rejection rates, Wilson intervals, Monte Carlo standard errors, and the initial negative-control screen.

## v0.7.2 calibration run

With 200 replicates per scenario, 32 independent parent blocks, 10 steps per period, alpha 0.05, and base seed 42000, the four negative controls produced screening rejection rates of 0.050 (null), 0.040 (AR-only), 0.055 (trend-only), and 0.045 (learning-only). The initial engineering screen passed under its declared point-rate and Wilson-upper-bound cutoffs.

The weak-carryover scenario was detected in 168/200 runs (0.84); the stronger carryover scenarios were detected in 200/200 runs. These are results under the declared fixtures only, not generalized power estimates. Full tables and limitations are in `docs/06_v0.7.2_calibration_and_limits.md`.

## Relationship to earlier project artifacts

This release preserves the v0.7.1 data-contract schema version (`0.7.1`) for existing parent/branch/exposure/opportunity records while the package release advances to `0.7.2`. New synthetic manifests and diagnostic/calibration reports use schema version `0.7.2`.

The Experience Engine v0.6 and v0.7 longitudinal design are separate historical lines. The v0.6 source archive was not available as raw source in the current working runtime; this package therefore remains an additive standalone research module and does not claim v0.6 merge or API compatibility.

## Research and privacy boundaries

- Synthetic data only; do not load real user histories or private conversation data into this test harness.
- Do not record hidden chain-of-thought. Only declared synthetic assignments, observable trial-like outcomes, and diagnostic metadata are represented.
- RCD and permission controls remain external and authoritative.
- The simulator never grants permissions or executes real external actions.
- Behavioral choice patterns are functional observations, not evidence of feelings or phenomenal consciousness.

## Next planned increment

A subsequent iteration should stress the diagnostic under informative availability/missingness, assignment deviations, cross-parent dependence, longer-memory residual processes, and a block-respecting randomization-based comparator. Any inferential method must be calibrated against known generators before use on actual Agent experiments.
