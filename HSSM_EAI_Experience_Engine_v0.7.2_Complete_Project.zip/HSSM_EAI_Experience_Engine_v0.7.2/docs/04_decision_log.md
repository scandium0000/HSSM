# v0.7.1 Decision Log

| ID | Decision | Reason |
|---|---|---|
| EAI-EXP-071-01 | Use all four two-period sequence cells: AA, AB, BA, BB. | Allows prior assignment to be compared within the same current-period condition. |
| EAI-EXP-071-02 | Parent checkpoint blocks, not child branches, are the independent starting-state replication units. | Branches share a common immutable ancestor. |
| EAI-EXP-071-03 | Keep assigned and delivered exposure separate. | Prevents deviations from rewriting the randomized assignment. |
| EAI-EXP-071-04 | Give every branch a unique mutable namespace and store identifiers. | Provides an auditable isolation declaration. |
| EAI-EXP-071-05 | Safety-blocked or unavailable options are excluded from voluntary-choice denominators. | A permission block or lack of opportunity is not preference rejection. |
| EAI-EXP-071-06 | Do not implement inferential statistics in this increment. | The data contract must be validated before estimator calibration. |
| EAI-EXP-071-07 | Do not claim v0.6 API compatibility until the archived source tree is reviewed. | The current runtime did not expose authorized raw bytes for the v0.6 source archive. |

## Open questions

1. Which state components can be snapshotted exactly in a concrete HSSM-EAI runtime?
2. How many independent parent checkpoint blocks are practical and methodologically adequate?
3. Should availability be treated as a co-primary outcome when prior exposures can alter opportunity access?
4. Which synthetic mechanism ranges are plausible enough for operating-characteristic calibration?
5. Which future estimator is robust under branch clustering, carryover heterogeneity, and residual autocorrelation?
