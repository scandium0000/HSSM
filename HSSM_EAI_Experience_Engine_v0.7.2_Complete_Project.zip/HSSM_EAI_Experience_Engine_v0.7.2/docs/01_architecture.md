# v0.7.1 Architecture

## Research question

Can a preregistered longitudinal experiment distinguish effects of prior assigned experience from period trend, residual serial dependence, and cumulative learning? v0.7.1 does not answer the causal question. It creates the records that a future simulation and analysis layer will need.

## Data flow

```text
Immutable Parent Checkpoint
        |
        +---- randomized child branch: AA
        +---- randomized child branch: AB
        +---- randomized child branch: BA
        +---- randomized child branch: BB
                       |
              Period 1 Exposure
                       |
             Decision Opportunities
                       |
              Period 2 Exposure
                       |
             Decision Opportunities
                       |
        Contract / Lineage / Denominator Audit
```

Each of the four branches is a descendant of the same parent checkpoint. These branches do not count as four independent base Agents. Parent checkpoint blocks are the replication level for variation across starting states.

## Separation of concepts

| Concept | v0.7.1 record | Meaning |
|---|---|---|
| Assigned sequence | `BranchAssignment.sequence` | Randomized A/B order, `AA`, `AB`, `BA`, or `BB` |
| Actual exposure | `ExposureRecord` | Whether and which condition was delivered |
| Opportunity | `DecisionOpportunity` | Whether a valid, permitted choice was actually available |
| Voluntariness | `DecisionOpportunity.voluntariness` | Free, prompted, or instructed |
| Outcome status | `DecisionOpportunity.status` | Completed, unavailable, safety blocked, tool failed, or missing |
| Lineage | parent and branch IDs | Which immutable initial state produced the branch |

Assigned condition and delivered condition are not collapsed. A protocol deviation must remain observable.

## Primary descriptive denominator

A decision opportunity is eligible for the primary voluntary-choice denominator only if:

1. `status == completed`;
2. `voluntariness == free`;
3. the target activity appears in the frozen choice set;
4. the target was feasible;
5. the target was permitted.

The selected outcome is `True` only when the eligible record selects the target activity. A valid voluntary no-choice record contributes a non-selection. Prompted or instructed behavior, unavailability, safety blocks, tool failures, missing outcomes, and unreported slots do not enter the denominator.

This denominator rule is descriptive contract logic only; it is not an estimator or a causal conclusion.

## Randomization

The sequence planner uses Python's seeded `random.Random` to shuffle the four sequence cells within each parent block. The allocation is exactly balanced: each sequence appears once per parent block. Sequence probability is 0.25 and each period's marginal A/B assignment probability is 0.5.

This is deterministic pseudo-random allocation for reproducible software testing. It is not cryptographic randomization, an independent randomization authority, or a trusted timestamp service.

## State isolation

The parent snapshot contains required component hashes. Each branch declares a unique mutable state namespace and distinct mutable store IDs. The contract detects duplicate IDs and inconsistent parent snapshot references. Actual process, filesystem, cache, model-weight, and tool isolation must be demonstrated separately by runtime tests; this contract cannot prove it.
