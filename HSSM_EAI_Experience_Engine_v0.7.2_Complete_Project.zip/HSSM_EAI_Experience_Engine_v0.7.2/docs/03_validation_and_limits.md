# v0.7.1 Validation Plan and Limits

## Contract-level checks

- protocol fields, target and choice-set consistency;
- complete parent snapshot component hashes;
- exactly four sequence cells in every parent block;
- deterministic seeded allocation;
- no duplicate branch IDs, mutable namespaces, or mutable store IDs;
- parent snapshot hashes consistent within a block;
- exactly one exposure record per branch-period;
- assigned exposure matches the randomized sequence;
- deviations include reason codes;
- choice sets are frozen and feasible/permitted subsets are valid;
- completed selections were feasible and permitted;
- unavailable, safety-blocked, failed, and missing outcomes have reason codes;
- scheduled-but-unreported opportunities remain distinct from recorded missing events;
- target availability and voluntariness control denominator inclusion.

## What tests establish

Unit tests establish that the Python implementation enforces these rules on the tested records. A synthetic CLI demo establishes that the package can generate, serialize, reload, and validate one reproducible fixture.

## What tests do not establish

- the physical or process-level isolation of a live Agent;
- truthfulness of a system's claimed exposure or choice logs;
- correctness or completeness of the checkpoint manifest for a particular model runtime;
- randomization fairness beyond the declared seeded algorithm;
- absence of hidden schedulers, prompts, external controllers, or shared resources;
- causal identifiability, estimator calibration, statistical power, or confidence-interval coverage;
- genuine preference, emotion, subjective experience, or consciousness.

## Next gate

v0.7.2 should implement known synthetic data generators and Monte Carlo calibration. The most important negative controls are AR-only and trend-only data: the future method must not mistake residual autocorrelation or time drift for causal carryover. A method that fails those checks must remain exploratory.
