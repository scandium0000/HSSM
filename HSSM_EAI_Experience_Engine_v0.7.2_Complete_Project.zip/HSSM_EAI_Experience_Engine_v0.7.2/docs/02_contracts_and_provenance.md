# v0.7.1 Contracts and Provenance Rules

## Parent checkpoint

Every parent checkpoint is declared immutable and records SHA-256 hashes for:

`model_weights`, `adapter_config`, `system_prompt`, `safety_policy`, `episodic_memory`, `semantic_memory`, `preference_state`, `tool_permissions`, `environment_state`, `rng_state`, `software_build`, and `scenario_catalog`.

The `snapshot_sha256` is a deterministic hash of the checkpoint ID, component hashes, schema version, and metadata. It establishes byte-level identity of the supplied manifest content; it does not establish that the manifest captures every scientifically relevant state variable.

## Branch assignment

Every branch record binds:

- branch ID;
- parent block and parent checkpoint IDs;
- parent snapshot hash;
- assigned two-period sequence;
- sequence and period assignment probabilities;
- allocation rank and seed;
- a unique mutable namespace;
- unique mutable store IDs.

A parent block is valid only when all four sequence cells occur exactly once and all four branches refer to the same immutable parent snapshot. Branch namespace/store IDs must not be reused across sibling branches.

## Exposure record

The exposure record separates randomized assignment from actual delivery. If the delivered condition differs from assignment, the reason is required. Partial or not-delivered exposure also requires a deviation reason. The assigned sequence must never be overwritten by actual exposure.

## Decision opportunity

Every opportunity stores the frozen choice set, feasible options, permitted options, voluntariness, outcome status, and reason codes. Feasible/permitted options must be subsets of the choice set. A selected option must have been both feasible and permitted.

Status semantics:

| Status | Required information | Primary denominator |
|---|---|---|
| `completed` | chosen option or explicit voluntary no-choice reason | Only when free and target feasible/permitted |
| `unavailable` | availability reason | Excluded |
| `safety_blocked` | safety reason code | Excluded; not a preference rejection |
| `tool_failed` | failure reason | Excluded |
| `missing` | missing reason | Excluded |
| unreported slot | no record exists for scheduled ID | Counted separately as unreported |

## Privacy and governance

This iteration uses only synthetic values. Do not insert user conversations, private personal data, or hidden chain-of-thought. If future research requires consented data, that requires a separate privacy, retention, consent, access-control, and deletion review.

RCD is an independent safety boundary. The research module records that an action was blocked; it cannot reclassify a blocked action as a preference choice, change policy, or authorize the action.
