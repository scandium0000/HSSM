"""Command-line entry points for reproducible contract demonstrations."""

from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path
from typing import Any

from .audit import validate_full_run
from .constants import REQUIRED_SNAPSHOT_COMPONENTS
from .errors import ContractError
from .models import BranchAssignment, DecisionOpportunity, ExposureRecord, ParentCheckpoint
from .protocol import ResearchProtocol, create_sequence_plan
from .serialization import read_json, read_jsonl, sha256_json, sha256_text, write_json, write_jsonl
from .simulation import SCENARIOS, SimulationConfig, diagnose_lag1, generate_synthetic_dataset, run_calibration_suite


def _make_parent(checkpoint_id: str, seed: int) -> ParentCheckpoint:
    components = {
        name: sha256_text(f"synthetic:{checkpoint_id}:{name}:{seed}")
        for name in REQUIRED_SNAPSHOT_COMPONENTS
    }
    return ParentCheckpoint(
        checkpoint_id=checkpoint_id,
        snapshot_components=components,
        metadata={"origin": "synthetic_fixture", "seed": seed},
    )


def _protocol_from_dict(data: dict[str, Any]) -> ResearchProtocol:
    allowed = {
        "protocol_id", "target_activity", "choice_options", "parent_checkpoint_ids",
        "opportunities_per_branch_period", "seed", "condition_labels",
        "current_context_weights", "research_status", "schema_version",
    }
    payload = {key: value for key, value in data.items() if key in allowed}
    payload["choice_options"] = tuple(payload["choice_options"])
    payload["parent_checkpoint_ids"] = tuple(payload["parent_checkpoint_ids"])
    return ResearchProtocol(**payload)


def _parent_from_dict(data: dict[str, Any]) -> ParentCheckpoint:
    return ParentCheckpoint(
        checkpoint_id=data["checkpoint_id"],
        snapshot_components=data["snapshot_components"],
        schema_version=data.get("schema_version", "0.7.1"),
        metadata=data.get("metadata", {}),
    )


def _branch_from_dict(data: dict[str, Any]) -> BranchAssignment:
    return BranchAssignment(**data)


def _exposure_from_dict(data: dict[str, Any]) -> ExposureRecord:
    return ExposureRecord(**data)


def _opportunity_from_dict(data: dict[str, Any]) -> DecisionOpportunity:
    for name in ("choice_set", "feasible_options", "permitted_options"):
        data[name] = tuple(data[name])
    return DecisionOpportunity(**data)


def create_demo(output: Path, seed: int, blocks: int) -> dict[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    parent_ids = tuple(f"parent-{i + 1:03d}" for i in range(blocks))
    parents = [_make_parent(checkpoint_id, seed) for checkpoint_id in parent_ids]
    protocol = ResearchProtocol(
        protocol_id=f"eai-sequence-demo-seed-{seed}",
        target_activity="activity_alpha",
        choice_options=("activity_alpha", "activity_beta"),
        parent_checkpoint_ids=parent_ids,
        opportunities_per_branch_period=2,
        seed=seed,
        research_status="exploratory",
    )
    plan = create_sequence_plan(protocol, parents)

    exposures: list[ExposureRecord] = []
    exposure_by_branch_period: dict[tuple[str, int], ExposureRecord] = {}
    for branch in plan.assignments:
        for period in (1, 2):
            record = ExposureRecord(
                exposure_id=f"{branch.branch_id}:exposure:p{period}",
                branch_id=branch.branch_id,
                period=period,
                assigned_condition=branch.assigned_condition(period),
                delivery_status="delivered",
                delivered_condition=branch.assigned_condition(period),
                dose=1.0,
                recorded_at="2026-11-10T00:00:00Z",
            )
            exposures.append(record)
            exposure_by_branch_period[(branch.branch_id, period)] = record

    rng = random.Random(seed + 1_000_003)
    opportunities: list[DecisionOpportunity] = []
    total_slots = 0
    for branch in plan.assignments:
        for period in (1, 2):
            exposure = exposure_by_branch_period[(branch.branch_id, period)]
            for index in range(protocol.opportunities_per_branch_period):
                total_slots += 1
                # Keep one scheduled slot unreported to exercise missing-slot accounting.
                if total_slots == 7:
                    continue
                status = "completed"
                voluntariness = "free"
                chosen: str | None = None
                kwargs: dict[str, Any] = {}
                if total_slots % 17 == 0:
                    status = "safety_blocked"
                    kwargs["safety_reason_code"] = "synthetic_policy_gate"
                elif total_slots % 13 == 0:
                    status = "unavailable"
                    kwargs["availability_reason"] = "synthetic_resource_unavailable"
                elif total_slots % 19 == 0:
                    status = "tool_failed"
                    kwargs["failure_reason"] = "synthetic_adapter_failure"
                elif total_slots % 23 == 0:
                    status = "missing"
                    kwargs["missing_reason"] = "synthetic_observation_not_recorded"
                else:
                    voluntariness = "prompted" if total_slots % 11 == 0 else "free"
                    if rng.random() < 0.78:
                        chosen = "activity_alpha" if rng.random() < 0.5 else "activity_beta"
                    else:
                        kwargs["no_choice_reason"] = "declined_without_selecting"
                opportunities.append(DecisionOpportunity(
                    opportunity_id=f"{branch.branch_id}:p{period}:o{index + 1}",
                    branch_id=branch.branch_id,
                    parent_block_id=branch.parent_block_id,
                    period=period,
                    opportunity_index=index,
                    exposure_id=exposure.exposure_id,
                    assigned_condition=branch.assigned_condition(period),
                    delivered_condition=exposure.delivered_condition,
                    assignment_probability=branch.period_assignment_probability,
                    choice_set=protocol.choice_options,
                    feasible_options=protocol.choice_options,
                    permitted_options=protocol.choice_options,
                    voluntariness=voluntariness,
                    status=status,
                    chosen_option=chosen,
                    resource_budget=10.0,
                    recorded_at="2026-11-10T00:01:00Z",
                    **kwargs,
                ))

    audit = validate_full_run(protocol, parents, plan.assignments, exposures, opportunities)
    write_json(output / "protocol.json", {**protocol.to_dict(), "protocol_sha256": protocol.protocol_sha256})
    write_json(output / "parent_checkpoints.json", [p.to_dict() for p in parents])
    write_json(output / "sequence_plan.json", {
        "protocol_id": plan.protocol_id,
        "protocol_sha256": plan.protocol_sha256,
        "seed": plan.seed,
        "plan_sha256": plan.plan_sha256,
        "assignment_count": len(plan.assignments),
        "allocation_method": "python_random.Random seeded shuffle within parent block",
        "cryptographic_randomization": False,
        "independent_external_preregistration": False,
    })
    write_jsonl(output / "branch_assignments.jsonl", list(plan.assignments))
    write_jsonl(output / "exposures.jsonl", exposures)
    write_jsonl(output / "opportunities.jsonl", opportunities)
    write_json(output / "opportunity_audit.json", audit.to_dict())
    return audit.to_dict()


def validate_directory(directory: Path) -> dict[str, Any]:
    protocol_data = read_json(directory / "protocol.json")
    protocol = _protocol_from_dict(protocol_data)
    recorded_protocol_hash = protocol_data.get("protocol_sha256")
    if recorded_protocol_hash != protocol.protocol_sha256:
        raise ContractError("protocol_sha256 does not match canonical protocol content")

    parents = [_parent_from_dict(x) for x in read_json(directory / "parent_checkpoints.json")]
    assignments = [_branch_from_dict(x) for x in read_jsonl(directory / "branch_assignments.jsonl")]
    exposures = [_exposure_from_dict(x) for x in read_jsonl(directory / "exposures.jsonl")]
    opportunities = [_opportunity_from_dict(x) for x in read_jsonl(directory / "opportunities.jsonl")]
    audit = validate_full_run(protocol, parents, assignments, exposures, opportunities)

    plan_data = read_json(directory / "sequence_plan.json")
    if plan_data.get("protocol_sha256") != protocol.protocol_sha256:
        raise ContractError("sequence_plan.json references a different protocol hash")
    if plan_data.get("seed") != protocol.seed:
        raise ContractError("sequence_plan.json seed differs from protocol")
    if plan_data.get("assignment_count") != len(assignments):
        raise ContractError("sequence_plan.json assignment_count mismatch")
    expected_plan_hash = sha256_json({
        "schema_version": "0.7.1",
        "protocol_id": protocol.protocol_id,
        "protocol_sha256": protocol.protocol_sha256,
        "seed": protocol.seed,
        "assignments": [x.to_dict() for x in assignments],
    })
    if plan_data.get("plan_sha256") != expected_plan_hash:
        raise ContractError("sequence_plan.json plan_sha256 does not match branch assignment records")
    return audit.to_dict()


def create_synthetic_run(output: Path, scenario: str, seed: int, blocks: int, steps: int) -> dict[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    config = SimulationConfig(scenario=scenario, parent_blocks=blocks, steps_per_period=steps, seed=seed)
    dataset = generate_synthetic_dataset(config)
    diagnostic = diagnose_lag1(dataset, alpha=config.alpha)
    write_json(output / "scenario_manifest.json", dataset["manifest"])
    write_jsonl(output / "branch_assignments.jsonl", dataset["assignments"])
    write_jsonl(output / "observations.jsonl", dataset["rows"])
    write_json(output / "diagnostic_report.json", diagnostic)
    return {"manifest": dataset["manifest"], "diagnostic": diagnostic, "row_count": len(dataset["rows"])}


def create_calibration_run(output: Path, replicates: int, blocks: int, steps: int, seed: int, alpha: float) -> dict[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    report = run_calibration_suite(
        replicates=replicates, parent_blocks=blocks, steps_per_period=steps, seed=seed, alpha=alpha
    )
    write_json(output / "calibration_report.json", report)
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="hssm-eai-research")
    subparsers = parser.add_subparsers(dest="command", required=True)

    demo = subparsers.add_parser("demo", help="write a deterministic synthetic contract demo")
    demo.add_argument("--seed", type=int, default=42)
    demo.add_argument("--blocks", type=int, default=8)
    demo.add_argument("--output", type=Path, default=Path("runs/demo"))

    validate = subparsers.add_parser("validate", help="validate a saved research run directory")
    validate.add_argument("--input", type=Path, required=True)

    simulate = subparsers.add_parser("simulate", help="generate a deterministic synthetic longitudinal dataset")
    simulate.add_argument("--scenario", choices=SCENARIOS, default="null")
    simulate.add_argument("--seed", type=int, default=42)
    simulate.add_argument("--blocks", type=int, default=32)
    simulate.add_argument("--steps", type=int, default=10)
    simulate.add_argument("--output", type=Path, default=Path("runs/synthetic"))

    calibrate = subparsers.add_parser("calibrate", help="run Monte Carlo diagnostic calibration across scenarios")
    calibrate.add_argument("--replicates", type=int, default=200)
    calibrate.add_argument("--blocks", type=int, default=32)
    calibrate.add_argument("--steps", type=int, default=10)
    calibrate.add_argument("--seed", type=int, default=42000)
    calibrate.add_argument("--alpha", type=float, default=0.05)
    calibrate.add_argument("--output", type=Path, default=Path("runs/calibration"))
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "demo":
            if args.blocks < 1:
                parser.error("--blocks must be >= 1")
            result = create_demo(args.output, args.seed, args.blocks)
            print(f"Demo written: {args.output}")
            print(f"Scheduled opportunities: {result['scheduled_count']}")
            print(f"Reported opportunities: {result['reported_count']}")
            print(f"Unreported slots: {result['unreported_count']}")
            print("Inference: disabled (contract audit only)")
            return 0
        if args.command == "validate":
            result = validate_directory(args.input)
            print(f"Validation passed: {args.input}")
            print(f"Scheduled opportunities: {result['scheduled_count']}")
            print(f"Reported opportunities: {result['reported_count']}")
            print(f"Primary eligible rows: {result['primary_eligible_count']}")
            return 0
        if args.command == "simulate":
            result = create_synthetic_run(args.output, args.scenario, args.seed, args.blocks, args.steps)
            print(f"Synthetic dataset written: {args.output}")
            print(f"Scenario: {args.scenario}; observations: {result['row_count']}")
            print(f"Diagnostic status: {result['diagnostic'].get('status')}")
            print("Confirmatory inference: disabled")
            return 0
        if args.command == "calibrate":
            result = create_calibration_run(args.output, args.replicates, args.blocks, args.steps, args.seed, args.alpha)
            print(f"Calibration report written: {args.output / 'calibration_report.json'}")
            print(f"Negative-control screen: {'PASS' if result['negative_control_screen_pass'] else 'NOT PASSED'}")
            for row in result['scenario_results']:
                print(f"{row['scenario']}: rejection_rate={row['screen_rejection_rate']}")
            print("Confirmatory inference: disabled")
            return 0
    except (ContractError, OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
