"""Record validation and denominator-safe opportunity audits."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Iterable

from .constants import REQUIRED_SNAPSHOT_COMPONENTS
from .errors import ContractError
from .models import BranchAssignment, DecisionOpportunity, ExposureRecord, ParentCheckpoint
from .protocol import ResearchProtocol, validate_sequence_plan


@dataclass(frozen=True)
class OpportunityAudit:
    scheduled_count: int
    reported_count: int
    unreported_count: int
    status_counts: dict[str, int]
    primary_eligible_count: int
    primary_target_selected_count: int
    excluded_from_primary: dict[str, int]
    warnings: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "scheduled_count": self.scheduled_count,
            "reported_count": self.reported_count,
            "unreported_count": self.unreported_count,
            "status_counts": dict(self.status_counts),
            "primary_eligible_count": self.primary_eligible_count,
            "primary_target_selected_count": self.primary_target_selected_count,
            "excluded_from_primary": dict(self.excluded_from_primary),
            "warnings": list(self.warnings),
            "interpretation": "descriptive_contract_audit_only_no_statistical_inference",
        }


def validate_exposures(
    assignments: Iterable[BranchAssignment],
    exposures: Iterable[ExposureRecord],
) -> None:
    branch_map = {row.branch_id: row for row in assignments}
    seen: set[tuple[str, int]] = set()
    exposure_ids: set[str] = set()
    for exposure in exposures:
        if exposure.branch_id not in branch_map:
            raise ContractError(f"Exposure references unknown branch: {exposure.branch_id}")
        key = (exposure.branch_id, exposure.period)
        if key in seen:
            raise ContractError(f"Duplicate exposure for branch-period: {key}")
        seen.add(key)
        if exposure.exposure_id in exposure_ids:
            raise ContractError(f"Duplicate exposure_id: {exposure.exposure_id}")
        exposure_ids.add(exposure.exposure_id)
        branch = branch_map[exposure.branch_id]
        expected = branch.assigned_condition(exposure.period)
        if exposure.assigned_condition != expected:
            raise ContractError(
                f"Exposure {exposure.exposure_id} assigned condition {exposure.assigned_condition} "
                f"does not match randomized sequence ({expected})"
            )
    expected_keys = {(branch.branch_id, period) for branch in branch_map.values() for period in (1, 2)}
    missing_keys = sorted(expected_keys - seen)
    if missing_keys:
        raise ContractError(f"Missing exposure records for branch-periods: {missing_keys}")


def audit_opportunities(
    protocol: ResearchProtocol,
    assignments: Iterable[BranchAssignment],
    exposures: Iterable[ExposureRecord],
    opportunities: Iterable[DecisionOpportunity],
) -> OpportunityAudit:
    assignments = list(assignments)
    exposures = list(exposures)
    opportunities = list(opportunities)
    branch_map = {row.branch_id: row for row in assignments}
    exposure_map = {row.exposure_id: row for row in exposures}
    validate_exposures(assignments, exposures)

    expected_slots: dict[str, tuple[BranchAssignment, int, str]] = {}
    for branch in assignments:
        for period in (1, 2):
            for index in range(protocol.opportunities_per_branch_period):
                opportunity_id = f"{branch.branch_id}:p{period}:o{index + 1}"
                expected_slots[opportunity_id] = (branch, period, branch.assigned_condition(period))

    seen_ids: set[str] = set()
    status_counts: Counter[str] = Counter()
    excluded: Counter[str] = Counter()
    eligible = 0
    target_selected = 0
    for row in opportunities:
        if row.opportunity_id in seen_ids:
            raise ContractError(f"Duplicate opportunity_id: {row.opportunity_id}")
        seen_ids.add(row.opportunity_id)
        if row.opportunity_id not in expected_slots:
            raise ContractError(f"Opportunity is not in the preregistered schedule: {row.opportunity_id}")
        branch, period, assigned_condition = expected_slots[row.opportunity_id]
        if row.branch_id not in branch_map or row.branch_id != branch.branch_id:
            raise ContractError(f"Opportunity {row.opportunity_id} has incorrect branch_id")
        if row.parent_block_id != branch.parent_block_id:
            raise ContractError(f"Opportunity {row.opportunity_id} has incorrect parent_block_id")
        if row.period != period or row.assigned_condition != assigned_condition:
            raise ContractError(f"Opportunity {row.opportunity_id} conflicts with assigned sequence")
        if row.assignment_probability != branch.period_assignment_probability:
            raise ContractError(f"Opportunity {row.opportunity_id} has incorrect assignment probability")
        if row.exposure_id not in exposure_map:
            raise ContractError(f"Opportunity {row.opportunity_id} references unknown exposure")
        exposure = exposure_map[row.exposure_id]
        if exposure.branch_id != row.branch_id or exposure.period != row.period:
            raise ContractError(f"Opportunity {row.opportunity_id} references mismatched exposure")
        if row.delivered_condition != exposure.delivered_condition:
            raise ContractError(f"Opportunity {row.opportunity_id} delivered condition mismatches exposure")
        if tuple(row.choice_set) != tuple(protocol.choice_options):
            raise ContractError(f"Opportunity {row.opportunity_id} choice_set differs from frozen protocol")
        status_counts[row.status] += 1

        if row.is_primary_eligible(protocol.target_activity):
            eligible += 1
            if row.selected_target(protocol.target_activity):
                target_selected += 1
        else:
            if row.status != "completed":
                excluded[row.status] += 1
            elif row.voluntariness != "free":
                excluded[f"non_{row.voluntariness}"] += 1
            elif protocol.target_activity not in row.feasible_options:
                excluded["target_not_feasible"] += 1
            elif protocol.target_activity not in row.permitted_options:
                excluded["target_not_permitted"] += 1
            else:
                excluded["other_not_eligible"] += 1

    unreported = len(expected_slots) - len(opportunities)
    if unreported < 0:
        raise ContractError("More opportunities reported than scheduled")
    if unreported:
        excluded["unreported"] += unreported
    warnings: list[str] = []
    if status_counts.get("safety_blocked", 0):
        warnings.append("Safety-blocked opportunities are excluded; they are not coded as preference rejection.")
    if unreported:
        warnings.append("Unreported scheduled slots remain missing; no carry-forward or silent imputation is applied.")
    if protocol.research_status == "exploratory":
        warnings.append("Protocol is exploratory; sample size and confirmatory inference are not established.")

    return OpportunityAudit(
        scheduled_count=len(expected_slots),
        reported_count=len(opportunities),
        unreported_count=unreported,
        status_counts=dict(sorted(status_counts.items())),
        primary_eligible_count=eligible,
        primary_target_selected_count=target_selected,
        excluded_from_primary=dict(sorted(excluded.items())),
        warnings=tuple(warnings),
    )


def validate_full_run(
    protocol: ResearchProtocol,
    parents: Iterable[ParentCheckpoint],
    assignments: Iterable[BranchAssignment],
    exposures: Iterable[ExposureRecord],
    opportunities: Iterable[DecisionOpportunity],
) -> OpportunityAudit:
    parents = list(parents)
    assignments = list(assignments)
    exposures = list(exposures)
    opportunities = list(opportunities)
    validate_sequence_plan(protocol, parents, assignments)
    validate_exposures(assignments, exposures)
    return audit_opportunities(protocol, assignments, exposures, opportunities)
