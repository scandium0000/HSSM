"""HSSM-EAI longitudinal research and diagnostic layer, release 0.7.2."""

from .audit import OpportunityAudit, audit_opportunities, validate_exposures, validate_full_run
from .errors import AllocationError, ContractError
from .models import BranchAssignment, DecisionOpportunity, ExposureRecord, ParentCheckpoint
from .protocol import ResearchProtocol, SequencePlan, create_sequence_plan, validate_sequence_plan
from .simulation import (
    SimulationConfig,
    audit_synthetic_branch_isolation,
    calibrate_scenario,
    diagnose_lag1,
    generate_synthetic_dataset,
    run_calibration_suite,
)

__version__ = "0.7.2"

__all__ = [
    "AllocationError",
    "BranchAssignment",
    "ContractError",
    "DecisionOpportunity",
    "ExposureRecord",
    "OpportunityAudit",
    "ParentCheckpoint",
    "ResearchProtocol",
    "SequencePlan",
    "SimulationConfig",
    "audit_opportunities",
    "audit_synthetic_branch_isolation",
    "calibrate_scenario",
    "diagnose_lag1",
    "generate_synthetic_dataset",
    "run_calibration_suite",
    "create_sequence_plan",
    "validate_exposures",
    "validate_full_run",
    "validate_sequence_plan",
]
