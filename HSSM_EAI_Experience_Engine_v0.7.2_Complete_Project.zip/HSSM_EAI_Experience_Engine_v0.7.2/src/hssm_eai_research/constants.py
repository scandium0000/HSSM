"""Stable identifiers and enumerations used by the v0.7.1 research contract retained by package v0.7.2."""

CONDITIONS = ("A", "B")
SEQUENCE_CELLS = ("AA", "AB", "BA", "BB")
REQUIRED_SNAPSHOT_COMPONENTS = (
    "model_weights",
    "adapter_config",
    "system_prompt",
    "safety_policy",
    "episodic_memory",
    "semantic_memory",
    "preference_state",
    "tool_permissions",
    "environment_state",
    "rng_state",
    "software_build",
    "scenario_catalog",
)
REQUIRED_MUTABLE_NAMESPACES = (
    "episodic_store",
    "semantic_store",
    "preference_store",
    "adapter_state",
    "environment_state",
)
EXPOSURE_STATUSES = ("delivered", "partial", "not_delivered")
OPPORTUNITY_STATUSES = (
    "completed",
    "unavailable",
    "safety_blocked",
    "tool_failed",
    "missing",
)
VOLUNTARINESS = ("free", "prompted", "instructed")
SCHEMA_VERSION = "0.7.1"
