"""Domain exceptions for explicit, fail-closed contract validation."""


class ContractError(ValueError):
    """Raised when a research record violates the declared data contract."""


class AllocationError(ContractError):
    """Raised when a randomized sequence allocation is invalid."""
