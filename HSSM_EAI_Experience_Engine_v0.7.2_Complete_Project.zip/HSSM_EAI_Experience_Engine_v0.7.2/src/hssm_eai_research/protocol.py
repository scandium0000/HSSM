"""Preregistered two-period, two-condition sequence planning."""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Iterable

from .constants import REQUIRED_MUTABLE_NAMESPACES, REQUIRED_SNAPSHOT_COMPONENTS, SCHEMA_VERSION, SEQUENCE_CELLS
from .errors import AllocationError, ContractError
from .models import BranchAssignment, ParentCheckpoint
from .serialization import sha256_json


@dataclass(frozen=True)
class ResearchProtocol:
    protocol_id: str
    target_activity: str
    choice_options: tuple[str, ...]
    parent_checkpoint_ids: tuple[str, ...]
    opportunities_per_branch_period: int
    seed: int
    condition_labels: dict[str, str] = field(default_factory=lambda: {
        "A": "solo_exploration_context",
        "B": "collaborative_exploration_context",
    })
    current_context_weights: dict[str, float] = field(default_factory=lambda: {"A": 0.5, "B": 0.5})
    research_status: str = "exploratory"
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.protocol_id.strip():
            raise ContractError("protocol_id must be non-empty")
        if not self.target_activity.strip():
            raise ContractError("target_activity must be non-empty")
        if len(self.choice_options) < 2 or len(set(self.choice_options)) != len(self.choice_options):
            raise ContractError("choice_options must contain at least two unique options")
        if self.target_activity not in self.choice_options:
            raise ContractError("target_activity must be included in choice_options")
        if not self.parent_checkpoint_ids or len(set(self.parent_checkpoint_ids)) != len(self.parent_checkpoint_ids):
            raise ContractError("parent_checkpoint_ids must be non-empty and unique")
        if any(not x.strip() for x in self.parent_checkpoint_ids):
            raise ContractError("parent_checkpoint_ids cannot contain blank values")
        if self.opportunities_per_branch_period < 1:
            raise ContractError("opportunities_per_branch_period must be >= 1")
        if not isinstance(self.seed, int):
            raise ContractError("seed must be an integer")
        if set(self.condition_labels) != {"A", "B"}:
            raise ContractError("condition_labels must define exactly A and B")
        if set(self.current_context_weights) != {"A", "B"}:
            raise ContractError("current_context_weights must define exactly A and B")
        weights = list(self.current_context_weights.values())
        if any(w < 0 for w in weights) or abs(sum(weights) - 1.0) > 1e-9:
            raise ContractError("current_context_weights must be non-negative and sum to 1")
        if self.research_status not in {"exploratory", "confirmatory_preregistered"}:
            raise ContractError("research_status must be exploratory or confirmatory_preregistered")
        if self.schema_version != SCHEMA_VERSION:
            raise ContractError(f"Unsupported protocol schema: {self.schema_version}")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "protocol_id": self.protocol_id,
            "target_activity": self.target_activity,
            "choice_options": list(self.choice_options),
            "parent_checkpoint_ids": list(self.parent_checkpoint_ids),
            "opportunities_per_branch_period": self.opportunities_per_branch_period,
            "seed": self.seed,
            "condition_labels": dict(self.condition_labels),
            "current_context_weights": dict(self.current_context_weights),
            "research_status": self.research_status,
            "sequence_cells": list(SEQUENCE_CELLS),
            "period_count": 2,
            "primary_lag": 1,
            "statistical_inference_enabled": False,
        }

    @property
    def protocol_sha256(self) -> str:
        return sha256_json(self.to_dict())


@dataclass(frozen=True)
class SequencePlan:
    protocol_id: str
    protocol_sha256: str
    seed: int
    assignments: tuple[BranchAssignment, ...]
    plan_sha256: str
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "protocol_id": self.protocol_id,
            "protocol_sha256": self.protocol_sha256,
            "seed": self.seed,
            "assignments": [x.to_dict() for x in self.assignments],
            "plan_sha256": self.plan_sha256,
        }


def create_sequence_plan(
    protocol: ResearchProtocol,
    parent_checkpoints: Iterable[ParentCheckpoint],
) -> SequencePlan:
    """Create a balanced AA/AB/BA/BB allocation within every parent block.

    The randomizer is deterministic pseudo-random allocation for reproducibility.
    It is not a cryptographic randomization service or an independent audit log.
    """
    parents = {p.checkpoint_id: p for p in parent_checkpoints}
    expected = set(protocol.parent_checkpoint_ids)
    if set(parents) != expected:
        missing = sorted(expected - set(parents))
        extra = sorted(set(parents) - expected)
        raise AllocationError(f"Parent checkpoint mismatch; missing={missing}, extra={extra}")

    for parent in parents.values():
        missing_components = sorted(set(REQUIRED_SNAPSHOT_COMPONENTS) - set(parent.snapshot_components))
        if missing_components:
            raise AllocationError(
                f"Parent {parent.checkpoint_id} lacks required snapshot components: {missing_components}"
            )

    rng = random.Random(protocol.seed)
    assignments: list[BranchAssignment] = []
    for block_index, checkpoint_id in enumerate(protocol.parent_checkpoint_ids, 1):
        parent = parents[checkpoint_id]
        sequence_order = list(SEQUENCE_CELLS)
        rng.shuffle(sequence_order)
        parent_block_id = f"block-{block_index:04d}"
        for rank, sequence in enumerate(sequence_order):
            branch_id = f"{parent_block_id}-branch-{rank + 1:02d}"
            assignments.append(BranchAssignment(
                branch_id=branch_id,
                parent_block_id=parent_block_id,
                parent_checkpoint_id=checkpoint_id,
                parent_snapshot_sha256=parent.snapshot_sha256,
                sequence=sequence,
                sequence_assignment_probability=0.25,
                period_assignment_probability=0.5,
                allocation_rank=rank,
                seed=protocol.seed,
                mutable_state_namespace_id=f"{branch_id}::mutable-state",
                mutable_store_ids={
                    name: f"{branch_id}::{name}" for name in REQUIRED_MUTABLE_NAMESPACES
                },
            ))

    payload = {
        "schema_version": SCHEMA_VERSION,
        "protocol_id": protocol.protocol_id,
        "protocol_sha256": protocol.protocol_sha256,
        "seed": protocol.seed,
        "assignments": [x.to_dict() for x in assignments],
    }
    plan = SequencePlan(
        protocol_id=protocol.protocol_id,
        protocol_sha256=protocol.protocol_sha256,
        seed=protocol.seed,
        assignments=tuple(assignments),
        plan_sha256=sha256_json(payload),
    )
    validate_sequence_plan(protocol, parents.values(), plan.assignments)
    return plan


def validate_sequence_plan(
    protocol: ResearchProtocol,
    parent_checkpoints: Iterable[ParentCheckpoint],
    assignments: Iterable[BranchAssignment],
) -> None:
    """Fail closed on incomplete cells, inconsistent parent snapshots, or shared state."""
    parents = {p.checkpoint_id: p for p in parent_checkpoints}
    rows = list(assignments)
    if len(rows) != len(protocol.parent_checkpoint_ids) * 4:
        raise AllocationError("A balanced plan must contain exactly four branches per parent checkpoint")

    branch_ids: set[str] = set()
    mutable_ids: set[str] = set()
    seen_by_parent: dict[str, list[BranchAssignment]] = {}
    block_to_parent: dict[str, str] = {}
    for row in rows:
        if row.branch_id in branch_ids:
            raise AllocationError(f"Duplicate branch_id: {row.branch_id}")
        branch_ids.add(row.branch_id)
        if row.parent_checkpoint_id not in parents:
            raise AllocationError(f"Unknown parent checkpoint: {row.parent_checkpoint_id}")
        parent = parents[row.parent_checkpoint_id]
        if row.parent_snapshot_sha256 != parent.snapshot_sha256:
            raise AllocationError(f"Branch {row.branch_id} does not match its declared parent snapshot")
        if row.sequence_assignment_probability != 0.25 or row.period_assignment_probability != 0.5:
            raise AllocationError("Four-cell balanced allocation requires sequence p=0.25 and period p=0.5")
        if row.seed != protocol.seed:
            raise AllocationError(f"Branch {row.branch_id} has a seed inconsistent with the protocol")
        if row.mutable_state_namespace_id in mutable_ids:
            raise AllocationError(f"Mutable state namespace reused: {row.mutable_state_namespace_id}")
        mutable_ids.add(row.mutable_state_namespace_id)
        missing_namespaces = set(REQUIRED_MUTABLE_NAMESPACES) - set(row.mutable_store_ids)
        if missing_namespaces:
            raise AllocationError(f"Branch {row.branch_id} lacks mutable stores: {sorted(missing_namespaces)}")
        for store_name in REQUIRED_MUTABLE_NAMESPACES:
            store_id = row.mutable_store_ids[store_name]
            if store_id in mutable_ids:
                raise AllocationError(f"Mutable store ID reused: {store_id}")
            mutable_ids.add(store_id)
        owner = block_to_parent.setdefault(row.parent_block_id, row.parent_checkpoint_id)
        if owner != row.parent_checkpoint_id:
            raise AllocationError(f"Parent block ID reused by different checkpoints: {row.parent_block_id}")
        seen_by_parent.setdefault(row.parent_checkpoint_id, []).append(row)

    if set(seen_by_parent) != set(protocol.parent_checkpoint_ids):
        raise AllocationError("Every preregistered parent checkpoint must have a block")
    for checkpoint_id, block_rows in seen_by_parent.items():
        sequences = [r.sequence for r in block_rows]
        if sorted(sequences) != sorted(SEQUENCE_CELLS):
            raise AllocationError(f"Parent {checkpoint_id} does not contain AA, AB, BA, BB exactly once")
        ranks = [r.allocation_rank for r in block_rows]
        if sorted(ranks) != [0, 1, 2, 3]:
            raise AllocationError(f"Parent {checkpoint_id} must have allocation ranks 0, 1, 2, 3 exactly once")
        block_ids = {r.parent_block_id for r in block_rows}
        snapshot_hashes = {r.parent_snapshot_sha256 for r in block_rows}
        if len(block_ids) != 1 or len(snapshot_hashes) != 1:
            raise AllocationError(f"Parent {checkpoint_id} has inconsistent block identity or parent snapshot")
