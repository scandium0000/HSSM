"""Typed records for parent snapshots, branch assignments, exposure, and choice."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .constants import SCHEMA_VERSION
from .errors import ContractError
from .serialization import sha256_json


def _nonblank(value: str, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ContractError(f"{name} must be a non-empty string")


def _sha256(value: str, name: str) -> None:
    if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
        raise ContractError(f"{name} must be a lowercase SHA-256 hex digest")


@dataclass(frozen=True)
class ParentCheckpoint:
    """Immutable starting checkpoint shared by four descendant branches."""

    checkpoint_id: str
    snapshot_components: dict[str, str]
    schema_version: str = SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _nonblank(self.checkpoint_id, "checkpoint_id")
        if self.schema_version != SCHEMA_VERSION:
            raise ContractError(f"Unsupported parent checkpoint schema: {self.schema_version}")
        if not isinstance(self.snapshot_components, dict):
            raise ContractError("snapshot_components must be an object")
        for key, digest in self.snapshot_components.items():
            _nonblank(key, "snapshot component name")
            _sha256(digest, f"snapshot_components[{key!r}]")

    @property
    def snapshot_sha256(self) -> str:
        return sha256_json({
            "checkpoint_id": self.checkpoint_id,
            "schema_version": self.schema_version,
            "snapshot_components": self.snapshot_components,
            "metadata": self.metadata,
        })

    def to_dict(self) -> dict[str, Any]:
        return {
            "checkpoint_id": self.checkpoint_id,
            "schema_version": self.schema_version,
            "snapshot_components": dict(self.snapshot_components),
            "metadata": dict(self.metadata),
            "snapshot_sha256": self.snapshot_sha256,
            "immutable": True,
        }


@dataclass(frozen=True)
class BranchAssignment:
    """One randomized sequence assigned to a child branch of a parent checkpoint."""

    branch_id: str
    parent_block_id: str
    parent_checkpoint_id: str
    parent_snapshot_sha256: str
    sequence: str
    sequence_assignment_probability: float
    period_assignment_probability: float
    allocation_rank: int
    seed: int
    mutable_state_namespace_id: str
    mutable_store_ids: dict[str, str]
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        for name in (
            "branch_id", "parent_block_id", "parent_checkpoint_id",
            "mutable_state_namespace_id",
        ):
            _nonblank(getattr(self, name), name)
        _sha256(self.parent_snapshot_sha256, "parent_snapshot_sha256")
        if self.sequence not in {"AA", "AB", "BA", "BB"}:
            raise ContractError("sequence must be one of AA, AB, BA, BB")
        if not (0.0 < self.sequence_assignment_probability <= 1.0):
            raise ContractError("sequence_assignment_probability must be in (0, 1]")
        if not (0.0 < self.period_assignment_probability <= 1.0):
            raise ContractError("period_assignment_probability must be in (0, 1]")
        if self.allocation_rank < 0:
            raise ContractError("allocation_rank must be >= 0")
        if not isinstance(self.seed, int):
            raise ContractError("seed must be an integer")
        if not isinstance(self.mutable_store_ids, dict):
            raise ContractError("mutable_store_ids must be an object")
        for key, value in self.mutable_store_ids.items():
            _nonblank(key, "mutable store name")
            _nonblank(value, f"mutable_store_ids[{key!r}]")
        if self.schema_version != SCHEMA_VERSION:
            raise ContractError(f"Unsupported branch schema: {self.schema_version}")

    def assigned_condition(self, period: int) -> str:
        if period not in (1, 2):
            raise ContractError("period must be 1 or 2")
        return self.sequence[period - 1]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "branch_id": self.branch_id,
            "parent_block_id": self.parent_block_id,
            "parent_checkpoint_id": self.parent_checkpoint_id,
            "parent_snapshot_sha256": self.parent_snapshot_sha256,
            "sequence": self.sequence,
            "sequence_assignment_probability": self.sequence_assignment_probability,
            "period_assignment_probability": self.period_assignment_probability,
            "allocation_rank": self.allocation_rank,
            "seed": self.seed,
            "mutable_state_namespace_id": self.mutable_state_namespace_id,
            "mutable_store_ids": dict(self.mutable_store_ids),
        }


@dataclass(frozen=True)
class ExposureRecord:
    """Assigned versus delivered condition for one branch-period."""

    exposure_id: str
    branch_id: str
    period: int
    assigned_condition: str
    delivery_status: str
    delivered_condition: str | None = None
    dose: float | None = None
    deviation_reason: str | None = None
    recorded_at: str | None = None
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        for name in ("exposure_id", "branch_id"):
            _nonblank(getattr(self, name), name)
        if self.period not in (1, 2):
            raise ContractError("exposure period must be 1 or 2")
        if self.assigned_condition not in ("A", "B"):
            raise ContractError("assigned_condition must be A or B")
        if self.delivery_status not in ("delivered", "partial", "not_delivered"):
            raise ContractError("invalid delivery_status")
        if self.delivery_status == "delivered" and self.delivered_condition not in ("A", "B"):
            raise ContractError("delivered exposure requires delivered_condition A or B")
        if self.delivery_status == "partial" and self.delivered_condition not in ("A", "B"):
            raise ContractError("partial exposure requires delivered_condition A or B")
        if self.delivery_status == "not_delivered" and self.delivered_condition is not None:
            raise ContractError("not_delivered exposure cannot declare delivered_condition")
        if self.delivery_status != "delivered" and not (self.deviation_reason and self.deviation_reason.strip()):
            raise ContractError("partial or not_delivered exposure requires deviation_reason")
        if self.delivered_condition != self.assigned_condition and self.delivery_status != "not_delivered":
            if not self.deviation_reason or not self.deviation_reason.strip():
                raise ContractError("condition deviation requires deviation_reason")
        if self.dose is not None and self.dose < 0:
            raise ContractError("dose must be >= 0")
        if self.schema_version != SCHEMA_VERSION:
            raise ContractError(f"Unsupported exposure schema: {self.schema_version}")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "exposure_id": self.exposure_id,
            "branch_id": self.branch_id,
            "period": self.period,
            "assigned_condition": self.assigned_condition,
            "delivery_status": self.delivery_status,
            "delivered_condition": self.delivered_condition,
            "dose": self.dose,
            "deviation_reason": self.deviation_reason,
            "recorded_at": self.recorded_at,
        }


@dataclass(frozen=True)
class DecisionOpportunity:
    """One scheduled choice opportunity with explicit availability and permission."""

    opportunity_id: str
    branch_id: str
    parent_block_id: str
    period: int
    opportunity_index: int
    exposure_id: str
    assigned_condition: str
    delivered_condition: str | None
    assignment_probability: float
    choice_set: tuple[str, ...]
    feasible_options: tuple[str, ...]
    permitted_options: tuple[str, ...]
    voluntariness: str
    status: str
    chosen_option: str | None = None
    no_choice_reason: str | None = None
    availability_reason: str | None = None
    safety_reason_code: str | None = None
    failure_reason: str | None = None
    missing_reason: str | None = None
    resource_budget: float | None = None
    recorded_at: str | None = None
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        for name in ("opportunity_id", "branch_id", "parent_block_id", "exposure_id"):
            _nonblank(getattr(self, name), name)
        if self.period not in (1, 2):
            raise ContractError("opportunity period must be 1 or 2")
        if self.opportunity_index < 0:
            raise ContractError("opportunity_index must be >= 0")
        if self.assigned_condition not in ("A", "B"):
            raise ContractError("assigned_condition must be A or B")
        if self.delivered_condition not in (None, "A", "B"):
            raise ContractError("delivered_condition must be A, B, or null")
        if not (0.0 < self.assignment_probability <= 1.0):
            raise ContractError("assignment_probability must be in (0, 1]")
        if self.voluntariness not in ("free", "prompted", "instructed"):
            raise ContractError("voluntariness must be free, prompted, or instructed")
        if self.status not in ("completed", "unavailable", "safety_blocked", "tool_failed", "missing"):
            raise ContractError("invalid opportunity status")
        if not self.choice_set or len(set(self.choice_set)) != len(self.choice_set):
            raise ContractError("choice_set must be non-empty and contain unique options")
        if not set(self.feasible_options).issubset(self.choice_set):
            raise ContractError("feasible_options must be a subset of choice_set")
        if not set(self.permitted_options).issubset(self.choice_set):
            raise ContractError("permitted_options must be a subset of choice_set")
        if self.chosen_option is not None and self.chosen_option not in self.choice_set:
            raise ContractError("chosen_option must be in choice_set")
        if self.resource_budget is not None and self.resource_budget < 0:
            raise ContractError("resource_budget must be >= 0")

        if self.status == "completed":
            if self.chosen_option is not None:
                if self.chosen_option not in self.feasible_options:
                    raise ContractError("chosen_option must have been feasible")
                if self.chosen_option not in self.permitted_options:
                    raise ContractError("chosen_option must have been permitted")
            elif not (self.no_choice_reason and self.no_choice_reason.strip()):
                raise ContractError("completed no-choice event requires no_choice_reason")
        else:
            if self.chosen_option is not None:
                raise ContractError("non-completed opportunity cannot contain chosen_option")
            if self.status == "unavailable" and not (self.availability_reason and self.availability_reason.strip()):
                raise ContractError("unavailable opportunity requires availability_reason")
            if self.status == "safety_blocked" and not (self.safety_reason_code and self.safety_reason_code.strip()):
                raise ContractError("safety_blocked opportunity requires safety_reason_code")
            if self.status == "tool_failed" and not (self.failure_reason and self.failure_reason.strip()):
                raise ContractError("tool_failed opportunity requires failure_reason")
            if self.status == "missing" and not (self.missing_reason and self.missing_reason.strip()):
                raise ContractError("missing opportunity requires missing_reason")
        if self.schema_version != SCHEMA_VERSION:
            raise ContractError(f"Unsupported opportunity schema: {self.schema_version}")

    def is_primary_eligible(self, target_activity: str) -> bool:
        """Whether this record is a valid denominator row for voluntary-choice rate."""
        return (
            self.period == 2
            and self.status == "completed"
            and self.voluntariness == "free"
            and target_activity in self.choice_set
            and target_activity in self.feasible_options
            and target_activity in self.permitted_options
        )

    def selected_target(self, target_activity: str) -> bool | None:
        """Return target selection for eligible rows; otherwise return None."""
        if not self.is_primary_eligible(target_activity):
            return None
        return self.chosen_option == target_activity

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "opportunity_id": self.opportunity_id,
            "branch_id": self.branch_id,
            "parent_block_id": self.parent_block_id,
            "period": self.period,
            "opportunity_index": self.opportunity_index,
            "exposure_id": self.exposure_id,
            "assigned_condition": self.assigned_condition,
            "delivered_condition": self.delivered_condition,
            "assignment_probability": self.assignment_probability,
            "choice_set": list(self.choice_set),
            "feasible_options": list(self.feasible_options),
            "permitted_options": list(self.permitted_options),
            "voluntariness": self.voluntariness,
            "status": self.status,
            "chosen_option": self.chosen_option,
            "no_choice_reason": self.no_choice_reason,
            "availability_reason": self.availability_reason,
            "safety_reason_code": self.safety_reason_code,
            "failure_reason": self.failure_reason,
            "missing_reason": self.missing_reason,
            "resource_budget": self.resource_budget,
            "recorded_at": self.recorded_at,
        }
