"""Deterministic synthetic longitudinal generators and diagnostic calibration.

This module is deliberately diagnostic-only. It generates known mechanisms and
compares a simple block-aware lag-1 contrast against those known mechanisms.
It does not implement a confirmatory causal estimator for real agents.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from statistics import mean, stdev
from typing import Any, Iterable

from .errors import ContractError

SCENARIOS = (
    "null",
    "ar_only",
    "trend_only",
    "learning_only",
    "transient_carryover",
    "weak_carryover",
    "persistent_carryover",
    "combined",
    "heterogeneous_carryover",
    "missing_safety",
    "branch_contamination",
)

_NEGATIVE_CONTROLS = ("null", "ar_only", "trend_only", "learning_only")


@dataclass(frozen=True)
class SimulationConfig:
    scenario: str = "null"
    parent_blocks: int = 32
    steps_per_period: int = 10
    seed: int = 42
    alpha: float = 0.05
    minimum_observations_per_branch: int = 3

    def __post_init__(self) -> None:
        if self.scenario not in SCENARIOS:
            raise ContractError(f"scenario must be one of {', '.join(SCENARIOS)}")
        if self.parent_blocks < 8:
            raise ContractError("parent_blocks must be >= 8 for diagnostic simulation")
        if self.steps_per_period < 4:
            raise ContractError("steps_per_period must be >= 4")
        if not isinstance(self.seed, int):
            raise ContractError("seed must be an integer")
        if not (0.0 < self.alpha < 0.5):
            raise ContractError("alpha must be in (0, 0.5)")
        if self.minimum_observations_per_branch < 2:
            raise ContractError("minimum_observations_per_branch must be >= 2")


def _scenario_parameters(scenario: str) -> dict[str, float]:
    """Return explicit generator parameters; these are synthetic assumptions."""
    common = {
        "base_logit": -0.20,
        "current_effect": 0.35,
        "carryover_effect": 0.0,
        "carryover_decay": 0.0,
        "trend_effect": 0.0,
        "learning_effect": 0.0,
        "ar_rho": 0.0,
        "ar_scale": 0.50,
        "branch_sd": 0.30,
        "parent_sd": 0.20,
        "heterogeneity_sd": 0.0,
        "unavailable_rate": 0.0,
        "safety_block_rate": 0.0,
        "tool_failure_rate": 0.0,
        "missing_rate": 0.0,
    }
    presets = {
        "null": {},
        "ar_only": {"ar_rho": 0.70},
        "trend_only": {"trend_effect": 0.90},
        "learning_only": {"learning_effect": 0.85},
        "transient_carryover": {"carryover_effect": 0.95, "carryover_decay": 0.22},
        "weak_carryover": {"carryover_effect": 0.20},
        "persistent_carryover": {"carryover_effect": 0.70},
        "combined": {
            "carryover_effect": 0.65,
            "trend_effect": 0.35,
            "learning_effect": 0.25,
            "ar_rho": 0.50,
        },
        "heterogeneous_carryover": {
            "carryover_effect": 0.65,
            "heterogeneity_sd": 0.45,
            "ar_rho": 0.25,
        },
        "missing_safety": {
            "carryover_effect": 0.70,
            "unavailable_rate": 0.04,
            "safety_block_rate": 0.04,
            "tool_failure_rate": 0.02,
            "missing_rate": 0.03,
        },
        "branch_contamination": {"carryover_effect": 0.0},
    }
    common.update(presets[scenario])
    return common


def _sigmoid(value: float) -> float:
    if value >= 0:
        z = math.exp(-value)
        return 1.0 / (1.0 + z)
    z = math.exp(value)
    return z / (1.0 + z)


def generate_synthetic_dataset(config: SimulationConfig) -> dict[str, Any]:
    """Generate two-period four-sequence panel data with known latent mechanisms.

    Every parent block has exactly one branch for AA, AB, BA, and BB. Rows are
    observations, not a model's actual actions. All values are synthetic.
    """
    if config.scenario == "branch_contamination":
        return _generate_contamination_fixture(config)

    params = _scenario_parameters(config.scenario)
    rng = random.Random(config.seed)
    sequences = ["AA", "AB", "BA", "BB"]
    rows: list[dict[str, Any]] = []
    assignments: list[dict[str, Any]] = []

    for block_index in range(config.parent_blocks):
        parent_id = f"parent-{block_index + 1:04d}"
        parent_intercept = rng.gauss(0.0, params["parent_sd"])
        block_carryover = params["carryover_effect"]
        if params["heterogeneity_sd"]:
            block_carryover += rng.gauss(0.0, params["heterogeneity_sd"])

        randomized_sequences = sequences[:]
        rng.shuffle(randomized_sequences)
        for branch_index, sequence in enumerate(randomized_sequences):
            branch_id = f"{parent_id}-branch-{branch_index + 1}"
            branch_intercept = rng.gauss(0.0, params["branch_sd"])
            namespace_id = f"{branch_id}-mutable-state"
            assignments.append({
                "parent_block_id": parent_id,
                "branch_id": branch_id,
                "sequence": sequence,
                "mutable_state_namespace_id": namespace_id,
                "sequence_assignment_probability": 0.25,
            })
            ar_state = rng.gauss(0.0, 1.0)

            for period in (1, 2):
                prior_condition = sequence[0] if period == 2 else None
                current_condition = sequence[period - 1]
                for step in range(config.steps_per_period):
                    ar_state = (
                        params["ar_rho"] * ar_state
                        + math.sqrt(max(0.0, 1.0 - params["ar_rho"] ** 2)) * rng.gauss(0.0, 1.0)
                    )
                    normalized_time = (period - 1 + step / max(1, config.steps_per_period - 1)) / 2.0
                    trend_term = params["trend_effect"] * (normalized_time - 0.5)
                    cumulative_step = (period - 1) * config.steps_per_period + step
                    learning_fraction = math.log1p(cumulative_step) / math.log1p(2 * config.steps_per_period - 1)
                    learning_term = params["learning_effect"] * (learning_fraction - 0.5)
                    current_term = params["current_effect"] * (1.0 if current_condition == "A" else -1.0)
                    carryover_term = 0.0
                    if period == 2 and prior_condition is not None:
                        decay = math.exp(-params["carryover_decay"] * step)
                        carryover_term = block_carryover * decay * (1.0 if prior_condition == "A" else -1.0)

                    latent = (
                        params["base_logit"] + parent_intercept + branch_intercept
                        + current_term + trend_term + learning_term
                        + carryover_term + params["ar_scale"] * ar_state
                    )
                    probability = _sigmoid(latent)
                    draw = rng.random()
                    status = "completed"
                    outcome: bool | None
                    status_draw = rng.random()
                    cumulative = 0.0
                    for status_name, rate in (
                        ("unavailable", params["unavailable_rate"]),
                        ("safety_blocked", params["safety_block_rate"]),
                        ("tool_failed", params["tool_failure_rate"]),
                        ("missing", params["missing_rate"]),
                    ):
                        cumulative += rate
                        if status_draw < cumulative:
                            status = status_name
                            break
                    outcome = (draw < probability) if status == "completed" else None
                    rows.append({
                        "parent_block_id": parent_id,
                        "branch_id": branch_id,
                        "sequence": sequence,
                        "period": period,
                        "step": step,
                        "prior_condition": prior_condition,
                        "current_condition": current_condition,
                        "status": status,
                        "voluntariness": "free",
                        "target_selected": outcome,
                    })

    metadata = {
        "schema_version": "0.7.2",
        "scenario": config.scenario,
        "seed": config.seed,
        "parent_blocks": config.parent_blocks,
        "branches_per_parent": 4,
        "steps_per_period": config.steps_per_period,
        "assignment_cells": ["AA", "AB", "BA", "BB"],
        "synthetic_parameters": params,
        "contains_real_agent_data": False,
        "contains_personal_data": False,
        "interpretation": "synthetic_data_generator_validation_only",
    }
    return {"manifest": metadata, "assignments": assignments, "rows": rows}


def _generate_contamination_fixture(config: SimulationConfig) -> dict[str, Any]:
    """Emit an intentionally invalid namespace map for integrity-gate testing."""
    rng = random.Random(config.seed)
    assignments: list[dict[str, Any]] = []
    for block_index in range(config.parent_blocks):
        parent_id = f"parent-{block_index + 1:04d}"
        sequences = ["AA", "AB", "BA", "BB"]
        rng.shuffle(sequences)
        base_namespace = f"{parent_id}-shared-contaminated-state"
        for i, sequence in enumerate(sequences):
            assignments.append({
                "parent_block_id": parent_id,
                "branch_id": f"{parent_id}-branch-{i + 1}",
                "sequence": sequence,
                "mutable_state_namespace_id": base_namespace if i in (0, 1) else f"{parent_id}-isolated-{i}",
                "sequence_assignment_probability": 0.25,
            })
    collisions = []
    for parent_id in (f"parent-{i + 1:04d}" for i in range(config.parent_blocks)):
        by_namespace: dict[str, list[str]] = {}
        for row in assignments:
            if row["parent_block_id"] == parent_id:
                by_namespace.setdefault(row["mutable_state_namespace_id"], []).append(row["branch_id"])
        collisions.extend(
            {"parent_block_id": parent_id, "namespace_id": ns, "branch_ids": ids}
            for ns, ids in by_namespace.items() if len(ids) > 1
        )
    return {
        "manifest": {
            "schema_version": "0.7.2",
            "scenario": config.scenario,
            "seed": config.seed,
            "parent_blocks": config.parent_blocks,
            "branches_per_parent": 4,
            "steps_per_period": config.steps_per_period,
            "assignment_cells": ["AA", "AB", "BA", "BB"],
            "synthetic_parameters": {},
            "contains_real_agent_data": False,
            "contains_personal_data": False,
            "integrity_probe": True,
            "branch_isolation_valid": False,
            "detected_namespace_collisions": collisions,
            "interpretation": "deliberately_invalid_fixture_must_be_rejected",
        },
        "assignments": assignments,
        "rows": [],
    }



def audit_synthetic_branch_isolation(assignments: Iterable[dict[str, Any]]) -> dict[str, Any]:
    """Check four-cell completeness and global mutable namespace uniqueness."""
    grouped: dict[str, list[dict[str, Any]]] = {}
    global_owners: dict[str, list[dict[str, str]]] = {}
    branch_ids: set[str] = set()
    invalid_cells: list[dict[str, Any]] = []
    for row in assignments:
        parent_id = row.get("parent_block_id")
        branch_id = row.get("branch_id")
        namespace = row.get("mutable_state_namespace_id")
        if not isinstance(parent_id, str) or not parent_id:
            return {"valid": False, "reason": "missing_parent_block_id", "namespace_collisions": [], "invalid_sequence_blocks": []}
        if not isinstance(branch_id, str) or not branch_id or branch_id in branch_ids:
            invalid_cells.append({"parent_block_id": parent_id, "reason": "missing_or_duplicate_branch_id", "branch_id": branch_id})
        else:
            branch_ids.add(branch_id)
        if not isinstance(namespace, str) or not namespace:
            invalid_cells.append({"parent_block_id": parent_id, "reason": "missing_namespace", "branch_id": branch_id})
        else:
            global_owners.setdefault(namespace, []).append({"parent_block_id": parent_id, "branch_id": str(branch_id)})
        grouped.setdefault(parent_id, []).append(row)

    expected = {"AA", "AB", "BA", "BB"}
    for parent_id, rows in sorted(grouped.items()):
        sequences = [row.get("sequence") for row in rows]
        if len(rows) != 4 or set(sequences) != expected or len(sequences) != len(set(sequences)):
            invalid_cells.append({"parent_block_id": parent_id, "sequences": sequences})

    collisions = [
        {"namespace_id": namespace, "owners": owners}
        for namespace, owners in global_owners.items() if len(owners) > 1
    ]
    valid = bool(grouped) and not collisions and not invalid_cells
    return {
        "valid": valid,
        "parent_blocks_checked": len(grouped),
        "branch_count_checked": len(branch_ids),
        "namespace_collisions": collisions,
        "invalid_sequence_blocks": invalid_cells,
    }


def _normal_two_sided_p(z_value: float) -> float:
    return math.erfc(abs(z_value) / math.sqrt(2.0))


def diagnose_lag1(dataset: dict[str, Any], alpha: float = 0.05, minimum_observations_per_branch: int = 3) -> dict[str, Any]:
    """Compute a block-aware descriptive lag-1 contrast with asymptotic z screen.

    Within each parent block and fixed period-2 current condition, compare the
    mean outcome after prior A versus prior B. Average equally over current A/B,
    then estimate uncertainty across parent blocks. The p-value is a screening
    approximation, not a confirmatory causal result.
    """
    if not (0.0 < alpha < 0.5):
        raise ContractError("alpha must be in (0, 0.5)")
    isolation = audit_synthetic_branch_isolation(dataset.get("assignments", []))
    if not isolation["valid"]:
        return {
            "status": "invalid_branch_isolation",
            "diagnostic_name": "block_aware_lag1_contrast",
            "branch_isolation_valid": False,
            "branch_isolation_audit": isolation,
            "confirmatory_inference_enabled": False,
            "reason": "The branch assignment manifest fails the declared sequence or mutable-namespace isolation contract.",
        }

    grouped: dict[tuple[str, str, str], list[float]] = {}
    for row in dataset.get("rows", []):
        if row.get("period") != 2 or row.get("status") != "completed" or row.get("voluntariness") != "free":
            continue
        outcome = row.get("target_selected")
        if not isinstance(outcome, bool):
            continue
        prior = row.get("prior_condition")
        current = row.get("current_condition")
        if prior not in ("A", "B") or current not in ("A", "B"):
            continue
        key = (row["parent_block_id"], current, prior)
        grouped.setdefault(key, []).append(1.0 if outcome else 0.0)

    parents = sorted({key[0] for key in grouped})
    block_effects: list[float] = []
    incomplete_blocks: list[str] = []
    context_effects: dict[str, list[float]] = {"A": [], "B": []}
    for parent in parents:
        local_effects: list[float] = []
        local_context_effects: dict[str, float] = {}
        complete = True
        for current in ("A", "B"):
            a_values = grouped.get((parent, current, "A"), [])
            b_values = grouped.get((parent, current, "B"), [])
            if min(len(a_values), len(b_values)) < minimum_observations_per_branch:
                complete = False
                break
            contrast = mean(a_values) - mean(b_values)
            local_effects.append(contrast)
            local_context_effects[current] = contrast
        if complete and len(local_effects) == 2:
            block_effects.append((local_effects[0] + local_effects[1]) / 2.0)
            for current, contrast in local_context_effects.items():
                context_effects[current].append(contrast)
        else:
            incomplete_blocks.append(parent)

    if len(block_effects) < 2:
        return {
            "status": "insufficient_complete_parent_blocks",
            "diagnostic_name": "block_aware_lag1_contrast",
            "n_parent_blocks_used": len(block_effects),
            "n_parent_blocks_excluded": len(incomplete_blocks),
            "confirmatory_inference_enabled": False,
        }

    estimate = mean(block_effects)
    sd = stdev(block_effects)
    standard_error = sd / math.sqrt(len(block_effects))
    degenerate = standard_error <= 1e-15
    z_value = (None if degenerate else estimate / standard_error)
    p_value = (None if degenerate else _normal_two_sided_p(z_value))
    critical = 1.959963984540054
    return {
        "status": "degenerate_variance_review" if degenerate else "diagnostic_only",
        "diagnostic_name": "block_aware_lag1_contrast",
        "estimand_label": "prior_A_minus_prior_B_equal_weighted_over_current_contexts",
        "estimate": estimate,
        "standard_error_across_parent_blocks": standard_error,
        "z_approximation": z_value,
        "two_sided_normal_approx_p_value": p_value,
        "screen_reject_at_alpha": bool(p_value < alpha) if p_value is not None else False,
        "alpha": alpha,
        "normal_approx_interval_95": [estimate - critical * standard_error, estimate + critical * standard_error],
        "n_parent_blocks_used": len(block_effects),
        "n_parent_blocks_excluded": len(incomplete_blocks),
        "mean_contrast_current_A": mean(context_effects["A"]) if context_effects["A"] else None,
        "mean_contrast_current_B": mean(context_effects["B"]) if context_effects["B"] else None,
        "minimum_observations_per_branch": minimum_observations_per_branch,
        "confirmatory_inference_enabled": False,
        "interpretation_limit": "Asymptotic screening diagnostic for this synthetic design; not a confirmatory causal estimator or a measure of subjective experience.",
    }


def wilson_interval(successes: int, trials: int, z: float = 1.959963984540054) -> list[float]:
    if trials <= 0 or successes < 0 or successes > trials:
        raise ContractError("Wilson interval requires 0 <= successes <= trials and trials > 0")
    p_hat = successes / trials
    denom = 1.0 + (z * z / trials)
    center = (p_hat + z * z / (2.0 * trials)) / denom
    half = z * math.sqrt((p_hat * (1.0 - p_hat) / trials) + (z * z / (4.0 * trials * trials))) / denom
    return [max(0.0, center - half), min(1.0, center + half)]


def calibrate_scenario(
    scenario: str,
    replicates: int = 200,
    parent_blocks: int = 32,
    steps_per_period: int = 10,
    seed: int = 42000,
    alpha: float = 0.05,
) -> dict[str, Any]:
    if scenario not in SCENARIOS or scenario == "branch_contamination":
        raise ContractError("calibration scenario must be a statistical scenario, not branch_contamination")
    if replicates < 20:
        raise ContractError("replicates must be >= 20 for a minimally useful Monte Carlo screen")
    rejects = 0
    estimates: list[float] = []
    excluded_blocks: list[int] = []
    for replicate in range(replicates):
        config = SimulationConfig(
            scenario=scenario,
            parent_blocks=parent_blocks,
            steps_per_period=steps_per_period,
            seed=seed + replicate * 104729,
            alpha=alpha,
        )
        result = diagnose_lag1(generate_synthetic_dataset(config), alpha=alpha)
        if result.get("status") != "diagnostic_only":
            excluded_blocks.append(parent_blocks)
            continue
        rejects += int(bool(result["screen_reject_at_alpha"]))
        estimates.append(float(result["estimate"]))
        excluded_blocks.append(int(result["n_parent_blocks_excluded"]))
    valid = len(estimates)
    interval = wilson_interval(rejects, valid) if valid else None
    return {
        "scenario": scenario,
        "replicates_requested": replicates,
        "replicates_valid": valid,
        "replicates_invalid": replicates - valid,
        "alpha": alpha,
        "screen_rejection_count": rejects,
        "screen_rejection_rate": rejects / valid if valid else None,
        "screen_rejection_rate_wilson_95": interval,
        "monte_carlo_standard_error": math.sqrt((rejects / valid) * (1.0 - rejects / valid) / valid) if valid else None,
        "mean_estimated_lag1_contrast": mean(estimates) if estimates else None,
        "mean_parent_blocks_excluded_per_replicate": mean(excluded_blocks) if excluded_blocks else None,
        "interpretation": "Monte Carlo operating-characteristic screen under the declared synthetic generator only; not real-agent evidence.",
    }


def run_calibration_suite(
    replicates: int = 200,
    parent_blocks: int = 32,
    steps_per_period: int = 10,
    seed: int = 42000,
    alpha: float = 0.05,
) -> dict[str, Any]:
    scenarios = (
        "null", "ar_only", "trend_only", "learning_only",
        "transient_carryover", "weak_carryover", "persistent_carryover", "combined",
        "heterogeneous_carryover", "missing_safety",
    )
    results = [
        calibrate_scenario(
            scenario, replicates, parent_blocks, steps_per_period,
            seed + index * 1_000_003, alpha,
        )
        for index, scenario in enumerate(scenarios)
    ]
    negative = [row for row in results if row["scenario"] in _NEGATIVE_CONTROLS]
    negative_rates = [row["screen_rejection_rate"] for row in negative if row["screen_rejection_rate"] is not None]
    negative_upper = [row["screen_rejection_rate_wilson_95"][1] for row in negative if row["screen_rejection_rate_wilson_95"]]
    initial_screen_pass = (
        len(negative_rates) == len(_NEGATIVE_CONTROLS)
        and all(rate <= 0.08 for rate in negative_rates)
        and all(upper <= 0.13 for upper in negative_upper)
    )
    return {
        "schema_version": "0.7.2",
        "diagnostic_name": "block_aware_lag1_contrast",
        "replicates_per_scenario": replicates,
        "parent_blocks_per_replicate": parent_blocks,
        "steps_per_period": steps_per_period,
        "alpha": alpha,
        "negative_control_scenarios": list(_NEGATIVE_CONTROLS),
        "negative_control_screen_pass": initial_screen_pass,
        "negative_control_screening_rule": {
            "point_rejection_rate_max": 0.08,
            "wilson_95_upper_max": 0.13,
            "note": "Exploratory engineering screen, not a universal statistical acceptance standard.",
        },
        "scenario_results": results,
        "confirmatory_inference_enabled": False,
        "interpretation": "Calibration applies only to these synthetic data-generating assumptions and this specific screening statistic. It does not validate causal inference for real or evolving agents.",
    }
