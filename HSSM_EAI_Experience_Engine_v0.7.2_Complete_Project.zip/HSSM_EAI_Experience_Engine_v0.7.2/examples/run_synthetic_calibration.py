"""Run the v0.7.2 synthetic calibration suite without installing the CLI."""

from __future__ import annotations

import argparse
from pathlib import Path

from hssm_eai_research.serialization import write_json
from hssm_eai_research.simulation import run_calibration_suite


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--replicates", type=int, default=200)
    parser.add_argument("--blocks", type=int, default=32)
    parser.add_argument("--steps", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42000)
    parser.add_argument("--output", type=Path, default=Path("runs/calibration_from_example"))
    args = parser.parse_args()

    report = run_calibration_suite(
        replicates=args.replicates,
        parent_blocks=args.blocks,
        steps_per_period=args.steps,
        seed=args.seed,
    )
    args.output.mkdir(parents=True, exist_ok=True)
    write_json(args.output / "calibration_report.json", report)
    print(f"Wrote {args.output / 'calibration_report.json'}")
    print(f"Negative-control initial screen: {'PASS' if report['negative_control_screen_pass'] else 'NOT PASSED'}")
    print("Confirmatory inference remains disabled.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
